﻿function main_model_only()
% MAIN
% Single-file MATLAB pipeline for GSHP-only SWRC modeling.
% This file contains the full workflow in one .m:
% data preparation -> model training -> evaluation -> model result tables.

clearvars;
clc;
close all;
warning off;

projectRoot = fileparts(mfilename("fullpath"));
cfg = single_file_project_config(projectRoot);
ensure_single_file_dirs(cfg);
prepare_single_file_input(cfg);
rng(cfg.seed, "twister");

fprintf("=== Single-file GSHP SWRC pipeline ===\n");
fprintf("Project root: %s\n", cfg.projectRoot);
fprintf("Raw data root: %s\n", cfg.dataRawDir);
fprintf("Output root: %s\n\n", cfg.outputRoot);

dataBundle = prepare_gshp_dataset(cfg);
dataBundle.measured = prepare_measured_highoc_dataset(cfg, dataBundle.normStats);
snapshotPath = fullfile(cfg.outputRoot, "workspace_snapshot.mat");
if cfg.quickReuseSnapshot && isfile(snapshotPath)
    fprintf("Reusing existing GSHP-trained models from workspace_snapshot.mat ...\n");
    S = load(snapshotPath, "externalResults", "ablationResults");
    externalResults = S.externalResults;
    ablationResults = S.ablationResults;
else
    externalResults = run_external_comparisons_single(dataBundle, cfg);
    ablationResults = run_internal_ablations_single(dataBundle, cfg);
end
targetTuneResults = run_blacksoil_target_finetune_single(dataBundle, externalResults, ablationResults, cfg);
measuredResults = run_measured_highoc_evaluation_single(dataBundle, externalResults, ablationResults, cfg, targetTuneResults);
packageInfo = generate_single_file_final_outputs(dataBundle, externalResults, ablationResults, measuredResults, cfg);

save(fullfile(cfg.outputRoot, "workspace_snapshot.mat"), ...
    "dataBundle", "externalResults", "ablationResults", "measuredResults", "targetTuneResults", "packageInfo", "cfg");

fprintf("\n=== Done ===\n");
fprintf("Final package folder: %s\n", cfg.finalPackageDir);
fprintf("Final zip: %s\n", cfg.finalZipPath);
end

function cfg = single_file_project_config(projectRoot)
cfg = struct();
cfg.projectRoot = projectRoot;
cfg.seed = 42;
cfg.quickReuseSnapshot = true;
cfg.intermediateFigureVisible = "off";
cfg.finalFigureVisible = "off";
cfg.keepFinalFiguresOpen = false;
cfg.showTrainingProgress = false;
cfg.figureExportResolution = 300;

cfg.dataRawDir = fullfile(projectRoot, "data");
cfg.outputRoot = fullfile(projectRoot, "outputs");
cfg.dataProcessedDir = fullfile(cfg.outputRoot, "data_processed");
cfg.outputsFiguresDir = fullfile(cfg.outputRoot, "figures");
cfg.outputsTablesDir = fullfile(cfg.outputRoot, "tables");
cfg.outputsMetricsDir = fullfile(cfg.outputRoot, "metrics");
cfg.outputsModelsDir = fullfile(cfg.outputRoot, "models");
cfg.outputsReadmeDir = fullfile(cfg.outputRoot, "readme");
cfg.outputsQcDir = fullfile(cfg.outputRoot, "qc");
cfg.finalPackageDir = fullfile(cfg.outputRoot, "final_package");
cfg.finalZipPath = fullfile(cfg.outputRoot, "ready_to_run_outputs_package.zip");
cfg.measuredPackageRoot = fullfile(cfg.finalPackageDir, "updated_measured_highOC_outputs");
cfg.measuredPackageFiguresDir = fullfile(cfg.measuredPackageRoot, "figures");
cfg.measuredPackageTablesDir = fullfile(cfg.measuredPackageRoot, "tables");
cfg.measuredPackageCodeDir = fullfile(cfg.measuredPackageRoot, "code");
cfg.measuredPackageReportDir = fullfile(cfg.measuredPackageRoot, "report");
cfg.measuredPackageQcDir = fullfile(cfg.measuredPackageRoot, "qc");
cfg.measuredPackageZipPath = fullfile(fileparts(cfg.finalZipPath), "updated_measured_highOC_outputs.zip");

cfg.rawInputXlsx = fullfile(cfg.dataRawDir, "GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx");
cfg.rawInputCsv = fullfile(cfg.dataRawDir, "GSHP_formal_training_table_with_layer_id_plus_metadata.csv");
cfg.trainingSheetName = "training_table";
cfg.measuredSheetName = "text_table";
cfg.processedPointCsv = fullfile(cfg.dataProcessedDir, "gshp_points_clean.csv");
cfg.processedCurveCsv = fullfile(cfg.dataProcessedDir, "gshp_curves_clean.csv");
cfg.splitCurveCsv = fullfile(cfg.dataProcessedDir, "gshp_curve_splits.csv");
cfg.splitPointCsv = fullfile(cfg.dataProcessedDir, "gshp_point_splits.csv");
cfg.splitSummaryTxt = fullfile(cfg.dataProcessedDir, "split_summary.txt");

cfg.requiredColumns = { ...
    'layer_id','longitude','latitude','Sand','Silt','Clay','OC','BD', ...
    'pF','theta','method','source_db','reference','DOIs_URLs'};
cfg.metadataColumns = {'method','source_db','reference','DOIs_URLs'};
cfg.soilFeatureColumns = {'Sand','Silt','Clay','OC','BD'};
cfg.pointFeatureColumns = {'Sand','Silt','Clay','OC','BD','pF'};

cfg.split.trainRatio = 0.70;
cfg.split.valRatio = 0.15;
cfg.split.testRatio = 0.15;
cfg.split.highOCThreshold = 3.0;
cfg.split.highOCInclusive = false;

cfg.physics.solidDensity = 2.65;
cfg.physics.alphaEpsilon = 1e-6;
cfg.physics.nEpsilon = 1e-6;
cfg.physics.ocStep = 0.5;
cfg.physics.betaOC3 = 0.8;
cfg.physics.wetPFMax = 2.2;
cfg.physics.wetSlopeGridCount = 6;
cfg.physics.wetDrySplitPF = 4.2;
cfg.physics.monotonicityGridSize = 160;

cfg.cleaning.minBD = 0.6;
cfg.cleaning.maxBD = 1.9;

cfg.model.retcRidge = 1e-3;
cfg.training.deltaHuber = 0.03;
cfg.training.gradientClip = 5.0;
cfg.training.beta1 = 0.9;
cfg.training.beta2 = 0.999;
cfg.training.adamEpsilon = 1e-8;
cfg.training.verboseEvery = 25;
cfg.training.repeatRuns = 3;

cfg.training.parametric.stage1Epochs = 180;
cfg.training.parametric.stage2Epochs = 160;
cfg.training.parametric.lrStage1 = 1e-3;
cfg.training.parametric.lrStage2 = 3e-4;
cfg.training.parametric.highOCWeight = 3.5;
cfg.training.parametric.useSplitDataLoss = true;
cfg.training.parametric.lambdaWet = 1.0;
cfg.training.parametric.lambdaDry = 2.5;
cfg.training.parametric.lambdaDryCandidates = [2.0 2.5 3.0 4.0];
cfg.training.parametric.usePlateauAnchor = true;
cfg.training.parametric.lambdaPlateau = 2e-2;

cfg.training.point.epochs = 220;
cfg.training.point.lr = 8e-4;
cfg.training.point.lambdaMono = 0.2;
cfg.training.point.lambdaBound = 0.2;
cfg.training.point.lambdaWet = 0.05;
cfg.training.point.lambdaReg = 1e-4;
cfg.training.point.epsPF = 1e-3;
cfg.training.point.lossVariant = "equation4_strict";
cfg.training.point.lambda1 = 1.0;
cfg.training.point.lambda2 = 2.5;
cfg.training.point.lambda3 = 0.2;
cfg.training.point.lambda4 = 0.2;
cfg.training.point.lambda5 = 0.2;
cfg.training.point.lambda6 = 0.1;
cfg.training.point.S1 = 1024;
cfg.training.point.S2 = 512;
cfg.training.point.S3 = 512;
cfg.training.point.S4 = 1024;
cfg.training.point.dryLinearityPFRange = [5.0, 7.6];
cfg.training.point.pF0Lower = 6.2;
cfg.training.point.pF0Upper = 7.6;
cfg.training.point.airEntryPFRange = [-2.0, -0.3];

cfg.training.physics.lambdaOC1 = 0.002;
cfg.training.physics.lambdaOC2 = 0.002;
cfg.training.physics.lambdaOC3 = 0.002;
cfg.training.physics.lambdaSat = 0.001;
cfg.training.physics.lambdaReg = 1e-4;

cfg.figure4.preferredSoilTypes = ["Sand","Loam","Silt loam"];
cfg.figure4.minPreferredPoints = 5;
cfg.figure4.minFallbackPoints = 2;
cfg.figure4.maxRepresentativePoints = Inf;
cfg.figure4.maxDisplayedObservedPoints = 60;
cfg.figure4.predictionGridSize = 200;
cfg.figure4.selectionSplit = "test";

cfg.tables.figure1DataXlsx = fullfile(cfg.outputsTablesDir, "Figure 1 table.xlsx");
cfg.tables.figure2DataXlsx = fullfile(cfg.outputsTablesDir, "Figure 2 table.xlsx");
cfg.tables.figure3DataXlsx = fullfile(cfg.outputsTablesDir, "Figure 3 table.xlsx");
cfg.tables.figure4DataXlsx = fullfile(cfg.outputsTablesDir, "Figure 4 table.xlsx");
cfg.tables.externalComparisonResultsXlsx = fullfile(cfg.outputsTablesDir, "Figure 4 table.xlsx");
cfg.tables.internalAblationResultsXlsx = fullfile(cfg.outputsTablesDir, "Figure 5 table.xlsx");
cfg.tables.bestRunResultsXlsx = fullfile(cfg.outputsTablesDir, "best_run_results.xlsx");
cfg.tables.externalComparisonCsv = fullfile(cfg.outputsTablesDir, "external_comparison_results.csv");
cfg.tables.internalAblationCsv = fullfile(cfg.outputsTablesDir, "internal_ablation_results.csv");
cfg.tables.figure6DataXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure6_HighOC_ternary_texture_data.xlsx");
cfg.tables.figure7DataXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure7_HighOC_representative_SWRC_data.xlsx");
cfg.tables.figure8DataXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure8_external_comparison_metrics.xlsx");
cfg.tables.figure9DataXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure9_internal_ablation_metrics.xlsx");
cfg.tables.figure10DataXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure10_all_unscreened_measured_SWRC_data.xlsx");
cfg.tables.figure11DataXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure11_external_statistical_evidence_data.xlsx");
cfg.tables.figureDataSubsetQcXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure8_10_11_data_subset_QC.xlsx");
cfg.tables.figure10WetEndQcXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure10_wet_end_performance_QC.xlsx");
cfg.tables.figure10WetEndComparisonXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure10_wet_end_model_comparison.xlsx");
cfg.tables.figure8Figure11ConsistencyQcXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure8_vs_Figure11_metric_consistency_QC.xlsx");
cfg.tables.figure11CurveLevelMetricsXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure11_curve_level_metrics.xlsx");
cfg.tables.figure3RepresentativeSelectedXlsx = fullfile(cfg.outputsTablesDir, "Figure3_representative_selected_curves.xlsx");
cfg.tables.figure3RepresentativeSelectedQcXlsx = fullfile(cfg.outputsTablesDir, "Figure3_representative_selected_curves_QC.xlsx");
cfg.tables.figure3RepresentativePlottingXlsx = fullfile(cfg.outputsTablesDir, "Figure3_representative_plotting_data.xlsx");
cfg.tables.figure7RepresentativeSelectedXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure7_representative_selected_curves.xlsx");
cfg.tables.figure7RepresentativePlottingXlsx = fullfile(cfg.measuredPackageTablesDir, "Figure7_representative_plotting_data.xlsx");
cfg.tables.figure3Figure7SelectionQcXlsx = fullfile(cfg.outputsTablesDir, "Figure3_Figure7_selection_QC_report.xlsx");
cfg.tables.measuredQcXlsx = fullfile(cfg.measuredPackageRoot, "QC_report.xlsx");
cfg.tables.blacksoilTargetTuneXlsx = fullfile(cfg.outputsTablesDir, "blacksoil_target_finetune_results.xlsx");
cfg.tables.blacksoilTargetTuneCsv = fullfile(cfg.outputsMetricsDir, "blacksoil_target_finetune_results.csv");
cfg.reportSourceCandidates = { ...
    fullfile(fileparts(cfg.finalZipPath), "ready_to_run_outputs_package", "Report_2026-04-29_v2.docx"), ...
    fullfile(fileparts(cfg.finalZipPath), "ready_to_run_outputs_package", "Report_2026-04-29.docx"), ...
    fullfile(fileparts(cfg.finalZipPath), "ready_to_run_outputs_package", "Report.docx"), ...
    fullfile(cfg.projectRoot, "Report_2026-04-29.docx"), ...
    fullfile(cfg.projectRoot, "Report.docx")};

cfg.targetTune.trainRatio = 0.56;
cfg.targetTune.valRatio = 0.22;
cfg.targetTune.testRatio = 0.22;
cfg.targetTune.repeatRuns = 3;
cfg.targetTune.stage1Epochs = 0;
cfg.targetTune.stage2Epochs = 120;
cfg.targetTune.lrStage1 = cfg.training.parametric.lrStage1;
cfg.targetTune.lrStage2 = 1.5e-4;
cfg.targetTune.highOCWeight = cfg.training.parametric.highOCWeight;
cfg.targetTune.lambdaWet = cfg.training.parametric.lambdaWet;
cfg.targetTune.lambdaDry = cfg.training.parametric.lambdaDry;
cfg.targetTune.modelName = "HO_PINN_target_finetune";
cfg.targetTune.pointRepeatRuns = 3;
cfg.targetTune.parametricRepeatRuns = 3;
cfg.targetTune.pointEpochs = 140;
cfg.targetTune.pointLearningRate = 2e-4;
cfg.targetTune.retcWarmLambda = 5e-2;
cfg.targetTune.hoSearchRepeatRuns = 4;
cfg.targetTune.hoSearchVariants = ["A1","A1-S","A2","A2-S"];
cfg.targetTune.hoSearchStage2Epochs = 180;
cfg.targetTune.hoSearchLrStage2 = 1e-4;
cfg.targetTune.lambdaOC1 = 8e-4;
cfg.targetTune.lambdaOC2 = 8e-4;
cfg.targetTune.lambdaOC3 = 8e-4;
cfg.targetTune.lambdaSat = 3e-4;
cfg.targetTune.a1sRepeatRuns = 6;
cfg.targetTune.a1sStage2Epochs = 220;
cfg.targetTune.a1sLrStage2 = 8e-5;
cfg.targetTune.usePlateauAnchor = true;
cfg.targetTune.lambdaPlateau = 2e-2;
cfg.targetTune.plateauPFWindow = 0.35;
cfg.targetTune.plateauTopK = 1;
% Head-only target tuning turned out to be too restrictive on the small
% black-soil domain, so keep the code path available but disable it by
% default and use the stronger full-parameter HO-only fine-tuning setup.
cfg.targetTune.freezeTrunk = false;
end

function ensure_single_file_dirs(cfg)
dirs = {cfg.dataRawDir, cfg.dataProcessedDir, cfg.outputRoot, cfg.outputsFiguresDir, ...
    cfg.outputsTablesDir, cfg.outputsMetricsDir, cfg.outputsModelsDir, ...
    cfg.outputsReadmeDir, cfg.outputsQcDir, cfg.finalPackageDir, ...
    cfg.measuredPackageRoot, cfg.measuredPackageFiguresDir, cfg.measuredPackageTablesDir, ...
    cfg.measuredPackageCodeDir, cfg.measuredPackageReportDir, cfg.measuredPackageQcDir};
for i = 1:numel(dirs)
    if ~exist(dirs{i}, "dir")
        mkdir(dirs{i});
    end
end
end

function prepare_single_file_input(cfg)
if isfile(cfg.rawInputXlsx) || isfile(cfg.rawInputCsv)
    return;
end

candidates = { ...
    fullfile(cfg.projectRoot, 'data', 'GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx'), ...
    fullfile(cfg.projectRoot, 'data', 'GSHP_formal_training_table_with_layer_id_plus_metadata.csv'), ...
    fullfile('E:\小论文稿件\高有机质黑土的连续土壤水分特征曲线预测模型\数据', 'GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx'), ...
    fullfile('C:\Users\94340\Downloads', 'GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx'), ...
    fullfile('C:\Users\94340\Downloads', 'GSHP_formal_training_table_with_layer_id_plus_metadata.csv'), ...
    fullfile(cfg.projectRoot, 'GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx'), ...
    fullfile(cfg.projectRoot, 'GSHP_formal_training_table_with_layer_id_plus_metadata.csv')};

copied = false;
for i = 1:numel(candidates)
    if isfile(candidates{i})
        [~,~,ext] = fileparts(candidates{i});
        if strcmpi(ext, '.xlsx')
            copyfile(candidates{i}, cfg.rawInputXlsx);
        else
            copyfile(candidates{i}, cfg.rawInputCsv);
        end
        copied = true;
        break;
    end
end
if ~copied
    error('GSHP source file was not found. Put the xlsx/csv in Downloads or project root first.');
end
end

function results = run_external_comparisons_single(dataBundle, cfg)
fprintf("\n=== External comparison experiments ===\n");
retcResult = train_retc_baseline(dataBundle, cfg);
pointOptions = struct( ...
    "modelName", "WRR_style_point_PINN", ...
    "lossVariant", cfg.training.point.lossVariant);
pointResult = train_best_point_repeat(dataBundle, cfg, pointOptions);
hoOptions = struct( ...
    "modelName", "HO_PINN_parametric_final", ...
    "useDualBranch", false, ...
    "useHighOCEnhancement", true, ...
    "usePhysics", true, ...
    "useSplitDataLoss", cfg.training.parametric.useSplitDataLoss, ...
    "lambdaWet", cfg.training.parametric.lambdaWet, ...
    "lambdaDry", cfg.training.parametric.lambdaDry);
hoResult = train_best_parametric_repeat(dataBundle, cfg, hoOptions);

models = {retcResult.model, pointResult.model, hoResult.model};
labels = ["RETC_style_VG","WRR_style_point_PINN","HO_PINN_final"]';
displayNames = ["RETC-style VG","WRR-style point PINN","HO-PINN final"]';

testData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "test", dataBundle.normStats, cfg);
valData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "val", dataBundle.normStats, cfg);
metricTables = build_metric_table_bundle(models, labels, displayNames, testData, valData, cfg);

overallTable = metricTables.testOverall;
highOCTable = metricTables.testHighOCOverall;
writetable(overallTable, cfg.tables.externalComparisonCsv);
writetable(highOCTable, fullfile(cfg.outputsMetricsDir, "external_comparison_high_oc.csv"));
write_results_workbook_extended(cfg.tables.externalComparisonResultsXlsx, metricTables, "model_name");

results = struct();
results.models = models;
results.overallTable = overallTable;
results.highOCTable = highOCTable;
results.metricTables = metricTables;
results.bestRunInfo = struct( ...
    "RETC_style_VG", struct("runIndex", 1, "selectionMetric", NaN), ...
    "WRR_style_point_PINN", pointResult.bestRunInfo, ...
    "HO_PINN_parametric_final", hoResult.bestRunInfo);
end

function results = run_internal_ablations_single(dataBundle, cfg)
fprintf("\n=== Internal ablation experiments ===\n");
a0Options = struct( ...
    "modelName", "A0_ordinary_parametric", ...
    "useDualBranch", false, ...
    "useHighOCEnhancement", false, ...
    "usePhysics", false, ...
    "stage2Epochs", 0, ...
    "useSplitDataLoss", false, ...
    "lambdaWet", 1.0, ...
    "lambdaDry", 1.0);
a1Options = struct( ...
    "modelName", "A1_plus_high_oc_enhancement", ...
    "useDualBranch", false, ...
    "useHighOCEnhancement", true, ...
    "usePhysics", false, ...
    "useSplitDataLoss", false, ...
    "lambdaWet", 1.0, ...
    "lambdaDry", 1.0);
a1SplitOptions = struct( ...
    "modelName", "A1_splitLoss", ...
    "useDualBranch", false, ...
    "useHighOCEnhancement", true, ...
    "usePhysics", false, ...
    "useSplitDataLoss", true, ...
    "lambdaWet", cfg.training.parametric.lambdaWet, ...
    "lambdaDry", cfg.training.parametric.lambdaDry);
a2Options = struct( ...
    "modelName", "A2_original", ...
    "useDualBranch", false, ...
    "useHighOCEnhancement", true, ...
    "usePhysics", true, ...
    "useSplitDataLoss", false, ...
    "lambdaWet", 1.0, ...
    "lambdaDry", 1.0);
a2SplitOptions = struct( ...
    "modelName", "A2_splitLoss", ...
    "useDualBranch", false, ...
    "useHighOCEnhancement", true, ...
    "usePhysics", true, ...
    "useSplitDataLoss", true, ...
    "lambdaWet", cfg.training.parametric.lambdaWet, ...
    "lambdaDry", cfg.training.parametric.lambdaDry);

a0 = train_best_parametric_repeat(dataBundle, cfg, a0Options);
a1 = train_best_parametric_repeat(dataBundle, cfg, a1Options);
a1Split = train_best_parametric_repeat(dataBundle, cfg, a1SplitOptions);
a2 = train_best_parametric_repeat(dataBundle, cfg, a2Options);
a2Split = train_best_parametric_repeat(dataBundle, cfg, a2SplitOptions);

models = {a0.model, a1.model, a1Split.model, a2.model, a2Split.model};
labels = ["A0_ordinary_parametric","A1_plus_high_oc_enhancement","A1_splitLoss","A2_original","A2_splitLoss"]';
displayNames = ["A0 ordinary parametric","A1 + high-OC enhancement","A1 split-loss","A2 original","A2 split-loss"]';

testData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "test", dataBundle.normStats, cfg);
valData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "val", dataBundle.normStats, cfg);
metricTables = build_metric_table_bundle(models, labels, displayNames, testData, valData, cfg);

overallTable = metricTables.testOverall;
highOCTable = metricTables.testHighOCOverall;
writetable(overallTable, cfg.tables.internalAblationCsv);
writetable(highOCTable, fullfile(cfg.outputsMetricsDir, "internal_ablation_high_oc.csv"));
write_results_workbook_extended(cfg.tables.internalAblationResultsXlsx, metricTables, "ablation_name");

results = struct();
results.models = models;
results.overallTable = overallTable;
results.highOCTable = highOCTable;
results.metricTables = metricTables;
results.bestRunInfo = struct( ...
    "A0_ordinary_parametric", a0.bestRunInfo, ...
    "A1_plus_high_oc_enhancement", a1.bestRunInfo, ...
    "A1_splitLoss", a1Split.bestRunInfo, ...
    "A2_original", a2.bestRunInfo, ...
    "A2_splitLoss", a2Split.bestRunInfo);
end

function results = run_measured_highoc_evaluation_single(dataBundle, externalResults, ablationResults, cfg, targetTuneResults)
fprintf("\n=== Measured High-OC external evaluation ===\n");
fullIdentification = dataBundle.measured.identification;
if nargin >= 5 && ~isempty(targetTuneResults)
    measuredData = targetTuneResults.targetSplit.testData;
    extModels = targetTuneResults.externalModelsFinetuned;
    externalTable = targetTuneResults.externalHoldoutFinetunedTable;
    ablModels = targetTuneResults.ablationModelsFinetuned;
    ablationTable = targetTuneResults.ablationHoldoutFinetunedTable;
    evalIdentification = struct( ...
        "totalRows", height(measuredData.pointTable), ...
        "uniqueCurves", measuredData.nCurves, ...
        "bqLikeRows", sum(startsWith(string(measuredData.pointTable.layer_id), "BQ-", IgnoreCase=true)), ...
        "centrifugationRows", sum(strcmpi(strtrim(string(measuredData.pointTable.method)), "Centrifugation technique")), ...
        "layerIdList", unique(measuredData.curveTable.layer_id, "stable"));
    evaluationMode = "target-ft-holdout";
else
    measuredData = dataBundle.measured.data;
    extModels = externalResults.models;
    extLabels = ["VG","PINN","HO-PINN"]';
    extDisplay = ["VG","PINN","HO-PINN"]';
    externalTable = evaluate_models_to_table(extModels, extLabels, extDisplay, measuredData, cfg);
    ablModels = ablationResults.models;
    ablLabels = ["A0","A1","A1-S","A2","A2-S"]';
    ablDisplay = ablLabels;
    ablationTable = evaluate_models_to_table(ablModels, ablLabels, ablDisplay, measuredData, cfg);
    evalIdentification = fullIdentification;
    evaluationMode = "source-only-full";
end

results = struct();
results.measuredData = measuredData;
results.identification = fullIdentification;
results.evalIdentification = evalIdentification;
results.externalTable = externalTable;
results.ablationTable = ablationTable;
results.externalModels = extModels;
results.ablationModels = ablModels;
results.evaluationMode = evaluationMode;
end

function results = run_blacksoil_target_finetune_single(dataBundle, externalResults, ablationResults, cfg)
fprintf("\n=== Black-soil target-domain fine-tuning ===\n");

targetSplit = split_measured_target_domain(dataBundle.measured, cfg);

externalSourceModels = externalResults.models;
externalLabels = ["VG","PINN","HO-PINN"]';
externalDisplay = externalLabels;
externalSourceHoldoutTable = evaluate_models_to_table(externalSourceModels, externalLabels, externalDisplay, targetSplit.testData, cfg);
externalSourceFullTable = evaluate_models_to_table(externalSourceModels, externalLabels, externalDisplay, dataBundle.measured.data, cfg);

ablationSourceModels = ablationResults.models;
ablationLabels = ["A0","A1","A1-S","A2","A2-S"]';
ablationDisplay = ablationLabels;
ablationSourceHoldoutTable = evaluate_models_to_table(ablationSourceModels, ablationLabels, ablationDisplay, targetSplit.testData, cfg);
ablationSourceFullTable = evaluate_models_to_table(ablationSourceModels, ablationLabels, ablationDisplay, dataBundle.measured.data, cfg);
ablationFinetunedModels = fine_tune_ablation_models_to_target(ablationSourceModels, targetSplit, cfg);
ablationHoldoutFinetunedTable = evaluate_models_to_table(ablationFinetunedModels, ablationLabels, ablationDisplay, targetSplit.testData, cfg);
ablationFullFinetunedTable = evaluate_models_to_table(ablationFinetunedModels, ablationLabels, ablationDisplay, dataBundle.measured.data, cfg);

bestHO = select_best_ho_target_variant(ablationFinetunedModels, ablationHoldoutFinetunedTable, cfg);
externalFinetunedModels = fine_tune_external_models_to_target(externalSourceModels, targetSplit, cfg);
externalFinetunedModels{3} = bestHO.model;
externalHoldoutFinetunedTable = evaluate_models_to_table(externalFinetunedModels, externalLabels, externalDisplay, targetSplit.testData, cfg);
externalFullFinetunedTable = evaluate_models_to_table(externalFinetunedModels, externalLabels, externalDisplay, dataBundle.measured.data, cfg);

deltaTbl = blacksoil_delta_table(externalSourceHoldoutTable, externalHoldoutFinetunedTable);
splitSummary = table( ...
    ["train_curves";"val_curves";"test_curves";"train_points";"val_points";"test_points"], ...
    [targetSplit.trainData.nCurves; targetSplit.valData.nCurves; targetSplit.testData.nCurves; ...
     height(targetSplit.trainData.pointTable); height(targetSplit.valData.pointTable); height(targetSplit.testData.pointTable)], ...
    'VariableNames', {'item','value'});
runSummary = build_target_repeat_summary(externalFinetunedModels, ablationFinetunedModels);

write_tables_to_excel(cfg.tables.blacksoilTargetTuneXlsx, ...
    {'external_holdout_source','external_holdout_targetft','external_full_source','external_full_targetft', ...
     'ablation_holdout_source','ablation_holdout_targetft','ablation_full_source','ablation_full_targetft', ...
     'best_ho_variant','delta_metrics','split_summary','repeat_summary'}, ...
    {externalSourceHoldoutTable, externalHoldoutFinetunedTable, externalSourceFullTable, externalFullFinetunedTable, ...
     ablationSourceHoldoutTable, ablationHoldoutFinetunedTable, ablationSourceFullTable, ablationFullFinetunedTable, ...
     bestHO.summaryTable, deltaTbl, splitSummary, runSummary});
writetable(externalHoldoutFinetunedTable, cfg.tables.blacksoilTargetTuneCsv);

results = struct();
results.targetSplit = targetSplit;
results.externalModelsSource = externalSourceModels;
results.externalModelsFinetuned = externalFinetunedModels;
results.ablationModelsSource = ablationSourceModels;
results.ablationModelsFinetuned = ablationFinetunedModels;
results.externalSourceHoldoutTable = externalSourceHoldoutTable;
results.externalHoldoutFinetunedTable = externalHoldoutFinetunedTable;
results.externalSourceFullTable = externalSourceFullTable;
results.externalFullFinetunedTable = externalFullFinetunedTable;
results.ablationSourceHoldoutTable = ablationSourceHoldoutTable;
results.ablationHoldoutFinetunedTable = ablationHoldoutFinetunedTable;
results.ablationSourceFullTable = ablationSourceFullTable;
results.ablationFullFinetunedTable = ablationFullFinetunedTable;
results.bestHOTarget = bestHO;
results.deltaTable = deltaTbl;
results.workbookPath = cfg.tables.blacksoilTargetTuneXlsx;

bestSource = pick_best_metric_row(externalSourceHoldoutTable);
bestTarget = pick_best_metric_row(externalHoldoutFinetunedTable);
fprintf("Measured holdout best source-only: %s | RMSE %.6f | R2 %.6f\n", ...
    string(bestSource.Model), bestSource.RMSE, bestSource.R2);
fprintf("Measured holdout best target-ft:   %s | RMSE %.6f | R2 %.6f\n", ...
    string(bestTarget.Model), bestTarget.RMSE, bestTarget.R2);
fprintf("Selected HO target variant: %s | Val RMSE %.6f\n", string(bestHO.variantLabel), bestHO.bestValidationRMSE);
end

function result = train_best_point_repeat(dataBundle, cfg, options)
if isstring(options) || ischar(options)
    options = struct("modelName", string(options), "lossVariant", cfg.training.point.lossVariant);
end
bestMetric = inf;
bestResult = [];
bestInfo = struct("runIndex", NaN, "selectionMetric", NaN);
summaryRows = table();

for r = 1:cfg.training.repeatRuns
    runName = options.modelName + "_run" + string(r);
    candidate = train_point_pinn_baseline(dataBundle, cfg, ...
        modelName=runName, ...
        lossVariant=local_get_option(options, "lossVariant", cfg.training.point.lossVariant), ...
        seedOverride=cfg.seed + r - 1);
    metric = candidate.model.bestValRMSE;
    summaryRows = [summaryRows; table(string(options.modelName), r, metric, 'VariableNames', {'model_name','run_index','validation_rmse'})]; %#ok<AGROW>
    if metric < bestMetric
        bestMetric = metric;
        bestResult = candidate;
        bestInfo.runIndex = r;
        bestInfo.selectionMetric = metric;
    end
end

bestResult.model.name = options.modelName;
result = bestResult;
result.repeatSummary = summaryRows;
result.bestRunInfo = bestInfo;
end

function result = train_best_parametric_repeat(dataBundle, cfg, options)
bestMetric = inf;
bestResult = [];
bestInfo = struct("runIndex", NaN, "selectionMetric", NaN);
summaryRows = table();

for r = 1:cfg.training.repeatRuns
    runOptions = options;
    runOptions.modelName = options.modelName + "_run" + string(r);
    runOptions.seedOverride = cfg.seed + r - 1;
    candidate = train_parametric_swrc_model(dataBundle, cfg, ...
        modelName=runOptions.modelName, ...
        useDualBranch=runOptions.useDualBranch, ...
        useHighOCEnhancement=runOptions.useHighOCEnhancement, ...
        usePhysics=runOptions.usePhysics, ...
        useSplitDataLoss=local_get_option(runOptions, "useSplitDataLoss", cfg.training.parametric.useSplitDataLoss), ...
        stage1Epochs=local_get_option(runOptions, "stage1Epochs", cfg.training.parametric.stage1Epochs), ...
        stage2Epochs=local_get_option(runOptions, "stage2Epochs", cfg.training.parametric.stage2Epochs), ...
        lrStage1=local_get_option(runOptions, "lrStage1", cfg.training.parametric.lrStage1), ...
        lrStage2=local_get_option(runOptions, "lrStage2", cfg.training.parametric.lrStage2), ...
        highOCWeight=local_get_option(runOptions, "highOCWeight", cfg.training.parametric.highOCWeight), ...
        lambdaWet=local_get_option(runOptions, "lambdaWet", cfg.training.parametric.lambdaWet), ...
        lambdaDry=local_get_option(runOptions, "lambdaDry", cfg.training.parametric.lambdaDry), ...
        usePlateauAnchor=local_get_option(runOptions, "usePlateauAnchor", cfg.training.parametric.usePlateauAnchor), ...
        lambdaPlateau=local_get_option(runOptions, "lambdaPlateau", cfg.training.parametric.lambdaPlateau), ...
        seedOverride=runOptions.seedOverride);
    metric = candidate.model.bestValRMSE;
    summaryRows = [summaryRows; table(string(options.modelName), r, metric, 'VariableNames', {'model_name','run_index','validation_rmse'})]; %#ok<AGROW>
    if metric < bestMetric
        bestMetric = metric;
        bestResult = candidate;
        bestInfo.runIndex = r;
        bestInfo.selectionMetric = metric;
    end
end

bestResult.model.name = options.modelName;
result = bestResult;
result.repeatSummary = summaryRows;
result.bestRunInfo = bestInfo;
end

function value = local_get_option(options, fieldName, defaultValue)
if isfield(options, fieldName)
    value = options.(fieldName);
else
    value = defaultValue;
end
end

function row = local_metric_row_template()
row = struct("Model","", "DisplayName","", "R2",NaN, "RMSE",NaN, "MAE",NaN, ...
    "MAPE",NaN, "MBE",NaN, "MonotonicityRate",NaN, "ThetaLtZeroRate",NaN, ...
    "InvalidThetaRate",NaN, "ParameterValidityRate",NaN, ...
    "CurveRMSEMean",NaN, "CurveRMSEMedian",NaN);
end

function row = local_fill_metric_row(row, label, displayName, evalResult)
row.Model = string(label);
row.DisplayName = string(displayName);
row.R2 = evalResult.metrics.R2;
row.RMSE = evalResult.metrics.RMSE;
row.MAE = evalResult.metrics.MAE;
row.MAPE = evalResult.metrics.MAPE;
row.MBE = evalResult.metrics.MBE;
row.MonotonicityRate = evalResult.physics.monotonicityRate;
row.ThetaLtZeroRate = evalResult.physics.thetaLtZeroRate;
row.InvalidThetaRate = evalResult.physics.invalidThetaRate;
row.ParameterValidityRate = evalResult.physics.parameterValidityRate;
row.CurveRMSEMean = evalResult.metrics.CurveRMSEMean;
row.CurveRMSEMedian = evalResult.metrics.CurveRMSEMedian;
end

function sub = local_subset_split_data(splitData, curveMask, cfg)
curveIds = splitData.layerIds(curveMask);
pointMask = ismember(splitData.pointTable.layer_id, curveIds);
curveTable = splitData.curveTable(curveMask, :);
pointTable = splitData.pointTable(pointMask, :);
pointTable.split = repmat(string(splitData.name), height(pointTable), 1);
curveTable.split = repmat(string(splitData.name), height(curveTable), 1);
bundle.curveTable = curveTable;
bundle.pointTable = pointTable;
bundle.normStats = splitData.normStats;
sub = build_curve_array_data(bundle.curveTable, bundle.pointTable, splitData.name, bundle.normStats, cfg);
end

function sub = local_subset_split_data_by_point(splitData, pointMask, cfg, subsetSuffix)
pointMask = pointMask(:);
if isempty(pointMask) || ~any(pointMask)
    curveTable = splitData.curveTable([], :);
    pointTable = splitData.pointTable([], :);
else
    pointTable = splitData.pointTable(pointMask, :);
    curveIds = unique(pointTable.layer_id, "stable");
    curveTable = splitData.curveTable(ismember(splitData.curveTable.layer_id, curveIds), :);
end
pointTable.split = repmat(string(splitData.name) + "_" + string(subsetSuffix), height(pointTable), 1);
curveTable.split = repmat(string(splitData.name) + "_" + string(subsetSuffix), height(curveTable), 1);
bundle.curveTable = curveTable;
bundle.pointTable = pointTable;
bundle.normStats = splitData.normStats;
sub = build_curve_array_data(bundle.curveTable, bundle.pointTable, string(splitData.name) + "_" + string(subsetSuffix), bundle.normStats, cfg);
end

function metricTables = build_metric_table_bundle(models, labels, displayNames, testData, valData, cfg)
metricTables = struct();
metricTables.testOverall = evaluate_models_to_table(models, labels, displayNames, testData, cfg);
metricTables.testWet = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(testData, testData.pointTable.pF <= cfg.physics.wetDrySplitPF, cfg, "wet"), cfg);
metricTables.testDry = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(testData, testData.pointTable.pF > cfg.physics.wetDrySplitPF, cfg, "dry"), cfg);
metricTables.testHighOCOverall = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data(testData, testData.highOCMask, cfg), cfg);
metricTables.testHighOCWet = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(testData, testData.pointTable.pF <= cfg.physics.wetDrySplitPF & is_high_oc_mask(testData.pointTable.OC, cfg), cfg, "highoc_wet"), cfg);
metricTables.testHighOCDry = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(testData, testData.pointTable.pF > cfg.physics.wetDrySplitPF & is_high_oc_mask(testData.pointTable.OC, cfg), cfg, "highoc_dry"), cfg);

metricTables.valOverall = evaluate_models_to_table(models, labels, displayNames, valData, cfg);
metricTables.valWet = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(valData, valData.pointTable.pF <= cfg.physics.wetDrySplitPF, cfg, "wet"), cfg);
metricTables.valDry = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(valData, valData.pointTable.pF > cfg.physics.wetDrySplitPF, cfg, "dry"), cfg);
metricTables.valHighOCOverall = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data(valData, valData.highOCMask, cfg), cfg);
metricTables.valHighOCWet = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(valData, valData.pointTable.pF <= cfg.physics.wetDrySplitPF & is_high_oc_mask(valData.pointTable.OC, cfg), cfg, "highoc_wet"), cfg);
metricTables.valHighOCDry = evaluate_models_to_table(models, labels, displayNames, ...
    local_subset_split_data_by_point(valData, valData.pointTable.pF > cfg.physics.wetDrySplitPF & is_high_oc_mask(valData.pointTable.OC, cfg), cfg, "highoc_dry"), cfg);
end

function tbl = blacksoil_eval_table(modelNames, subsetNames, evalResults)
rows = numel(modelNames);
tbl = table('Size', [rows, 8], ...
    'VariableTypes', {'string','string','double','double','double','double','double','double'}, ...
    'VariableNames', {'model_name','subset','R2','RMSE','MAE','MAPE','MBE','MonotonicityRate'});
for i = 1:rows
    tbl.model_name(i) = string(modelNames(i));
    tbl.subset(i) = string(subsetNames(i));
    tbl.R2(i) = evalResults(i).metrics.R2;
    tbl.RMSE(i) = evalResults(i).metrics.RMSE;
    tbl.MAE(i) = evalResults(i).metrics.MAE;
    tbl.MAPE(i) = evalResults(i).metrics.MAPE;
    tbl.MBE(i) = evalResults(i).metrics.MBE;
    tbl.MonotonicityRate(i) = evalResults(i).physics.monotonicityRate;
end
end

function targetSplit = split_measured_target_domain(measuredBundle, cfg)
curveTable = measuredBundle.curveTable;
pointTable = measuredBundle.pointTable;
nCurves = height(curveTable);
if nCurves < 6
    error("Measured black-soil dataset is too small for target-domain fine-tuning split.");
end

rng(cfg.seed + 700, "twister");
perm = randperm(nCurves);
nTrain = max(8, floor(nCurves * cfg.targetTune.trainRatio));
nVal = max(3, floor(nCurves * cfg.targetTune.valRatio));
if nTrain + nVal >= nCurves
    nVal = max(2, nCurves - nTrain - 1);
end
nTest = nCurves - nTrain - nVal;
if nTest < 2
    nTest = 2;
    nTrain = max(6, nCurves - nVal - nTest);
end

curveTable.split = strings(nCurves, 1);
curveTable.split(perm(1:nTrain)) = "target_train";
curveTable.split(perm(nTrain+1:nTrain+nVal)) = "target_val";
curveTable.split(perm(nTrain+nVal+1:end)) = "target_test";

splitMap = curveTable(:, {'layer_id','split'});
pointTable = removevars(pointTable, intersect({'split'}, pointTable.Properties.VariableNames));
pointTable = innerjoin(pointTable, splitMap, Keys="layer_id");

targetSplit = struct();
targetSplit.curveTable = curveTable;
targetSplit.pointTable = pointTable;
targetSplit.trainData = build_curve_array_data(curveTable, pointTable, "target_train", measuredBundle.data.normStats, cfg);
targetSplit.valData = build_curve_array_data(curveTable, pointTable, "target_val", measuredBundle.data.normStats, cfg);
targetSplit.testData = build_curve_array_data(curveTable, pointTable, "target_test", measuredBundle.data.normStats, cfg);
end

function result = fine_tune_parametric_to_target(sourceModel, targetSplit, cfg, options)
arguments
    sourceModel struct
    targetSplit struct
    cfg struct
    options.modelName string = "HO_PINN_target_finetune"
    options.repeatRuns double = 3
    options.stage1Epochs double = 0
    options.stage2Epochs double = 120
    options.lrStage1 double = cfg.training.parametric.lrStage1
    options.lrStage2 double = 1.5e-4
    options.highOCWeight double = cfg.training.parametric.highOCWeight
    options.lambdaWet double = cfg.training.parametric.lambdaWet
    options.lambdaDry double = cfg.training.parametric.lambdaDry
    options.lambdaOC1 double = cfg.training.physics.lambdaOC1
    options.lambdaOC2 double = cfg.training.physics.lambdaOC2
    options.lambdaOC3 double = cfg.training.physics.lambdaOC3
    options.lambdaSat double = cfg.training.physics.lambdaSat
    options.lambdaReg double = cfg.training.physics.lambdaReg
    options.usePlateauAnchor logical = cfg.training.parametric.usePlateauAnchor
    options.lambdaPlateau double = cfg.training.parametric.lambdaPlateau
    options.freezeTrunk logical = false
end

bestMetric = inf;
bestResult = [];
summaryRows = table();
if isfield(sourceModel, "options") && isstruct(sourceModel.options)
    useHighOCEnhancement = local_get_option(sourceModel.options, "useHighOCEnhancement", true);
    usePhysics = local_get_option(sourceModel.options, "usePhysics", true);
    useSplitDataLoss = local_get_option(sourceModel.options, "useSplitDataLoss", true);
else
    useHighOCEnhancement = true;
    usePhysics = true;
    useSplitDataLoss = true;
end

for r = 1:options.repeatRuns
    runName = options.modelName + "_run" + string(r);
    candidate = train_parametric_swrc_model(struct(), cfg, ...
        modelName=runName, ...
        useDualBranch=sourceModel.useDualBranch, ...
        useHighOCEnhancement=useHighOCEnhancement, ...
        usePhysics=usePhysics, ...
        useSplitDataLoss=useSplitDataLoss, ...
        stage1Epochs=options.stage1Epochs, ...
        stage2Epochs=options.stage2Epochs, ...
        lrStage1=options.lrStage1, ...
        lrStage2=options.lrStage2, ...
        highOCWeight=options.highOCWeight, ...
        lambdaWet=options.lambdaWet, ...
        lambdaDry=options.lambdaDry, ...
        lambdaOC1=local_get_option(options, "lambdaOC1", cfg.training.physics.lambdaOC1), ...
        lambdaOC2=local_get_option(options, "lambdaOC2", cfg.training.physics.lambdaOC2), ...
        lambdaOC3=local_get_option(options, "lambdaOC3", cfg.training.physics.lambdaOC3), ...
        lambdaSat=local_get_option(options, "lambdaSat", cfg.training.physics.lambdaSat), ...
        lambdaReg=local_get_option(options, "lambdaReg", cfg.training.physics.lambdaReg), ...
        usePlateauAnchor=local_get_option(options, "usePlateauAnchor", false), ...
        lambdaPlateau=local_get_option(options, "lambdaPlateau", 0), ...
        freezeTrunk=local_get_option(options, "freezeTrunk", false), ...
        seedOverride=cfg.seed + 900 + r - 1, ...
        initParams=sourceModel.params, ...
        customTrainData=targetSplit.trainData, ...
        customValData=targetSplit.valData);
    metric = candidate.model.bestValRMSE;
    summaryRows = [summaryRows; table(string(options.modelName), r, metric, 'VariableNames', {'model_name','run_index','validation_rmse'})]; %#ok<AGROW>
    if metric < bestMetric
        bestMetric = metric;
        bestResult = candidate;
    end
end

bestResult.model.name = options.modelName;
result = bestResult;
result.repeatSummary = summaryRows;
end

function modelsOut = fine_tune_external_models_to_target(sourceModels, targetSplit, cfg)
modelsOut = cell(size(sourceModels));
for i = 1:numel(sourceModels)
    thisModel = sourceModels{i};
    switch string(thisModel.kind)
        case "retc"
            modelsOut{i} = fine_tune_retc_to_target(thisModel, targetSplit, cfg, ...
                modelName="VG_target_ft");
        case "point"
            ft = fine_tune_point_to_target(thisModel, targetSplit, cfg, ...
                modelName="PINN_target_ft", ...
                repeatRuns=cfg.targetTune.pointRepeatRuns, ...
                epochs=cfg.targetTune.pointEpochs, ...
                learningRate=cfg.targetTune.pointLearningRate);
            modelsOut{i} = ft.model;
        otherwise
            ft = fine_tune_parametric_to_target(thisModel, targetSplit, cfg, ...
                modelName="HO_PINN_target_ft", ...
                repeatRuns=cfg.targetTune.parametricRepeatRuns, ...
                stage1Epochs=cfg.targetTune.stage1Epochs, ...
                stage2Epochs=cfg.targetTune.stage2Epochs, ...
                lrStage1=cfg.targetTune.lrStage1, ...
                lrStage2=cfg.targetTune.lrStage2, ...
                highOCWeight=cfg.targetTune.highOCWeight, ...
                lambdaWet=cfg.targetTune.lambdaWet, ...
                lambdaDry=cfg.targetTune.lambdaDry, ...
                usePlateauAnchor=cfg.targetTune.usePlateauAnchor, ...
                lambdaPlateau=cfg.targetTune.lambdaPlateau);
            modelsOut{i} = ft.model;
    end
end
end

function modelsOut = fine_tune_ablation_models_to_target(sourceModels, targetSplit, cfg)
modelsOut = cell(size(sourceModels));
targetNames = ["A0_target_ft","A1_target_ft","A1-S_target_ft","A2_target_ft","A2-S_target_ft"];
for i = 1:numel(sourceModels)
    thisModel = sourceModels{i};
    sourceLabel = "";
    if isfield(thisModel, "name")
        sourceLabel = string(thisModel.name);
    end
    if isfield(thisModel, "options") && isstruct(thisModel.options) && isfield(thisModel.options, "modelName")
        sourceLabel = string(thisModel.options.modelName);
    end
    useHoSearch = any(strcmpi(sourceLabel, cfg.targetTune.hoSearchVariants));
    if useHoSearch
        repeatRuns = cfg.targetTune.hoSearchRepeatRuns;
        stage2Epochs = cfg.targetTune.hoSearchStage2Epochs;
        lrStage2 = cfg.targetTune.hoSearchLrStage2;
    else
        repeatRuns = cfg.targetTune.parametricRepeatRuns;
        stage2Epochs = cfg.targetTune.stage2Epochs;
        lrStage2 = cfg.targetTune.lrStage2;
    end
    lambdaOC1 = cfg.targetTune.lambdaOC1;
    lambdaOC2 = cfg.targetTune.lambdaOC2;
    lambdaOC3 = cfg.targetTune.lambdaOC3;
    lambdaSat = cfg.targetTune.lambdaSat;
    lambdaPlateau = cfg.targetTune.lambdaPlateau;
    if strcmpi(sourceLabel, "A1-S")
        repeatRuns = cfg.targetTune.a1sRepeatRuns;
        stage2Epochs = cfg.targetTune.a1sStage2Epochs;
        lrStage2 = cfg.targetTune.a1sLrStage2;
        lambdaOC1 = cfg.targetTune.lambdaOC1 * 0.75;
        lambdaOC2 = cfg.targetTune.lambdaOC2 * 0.75;
        lambdaOC3 = cfg.targetTune.lambdaOC3 * 0.75;
        lambdaSat = cfg.targetTune.lambdaSat * 0.6;
        lambdaPlateau = cfg.targetTune.lambdaPlateau * 1.25;
    end
    ft = fine_tune_parametric_to_target(thisModel, targetSplit, cfg, ...
        modelName=targetNames(min(i, numel(targetNames))), ...
        repeatRuns=repeatRuns, ...
        stage1Epochs=cfg.targetTune.stage1Epochs, ...
        stage2Epochs=stage2Epochs, ...
        lrStage1=cfg.targetTune.lrStage1, ...
        lrStage2=lrStage2, ...
        highOCWeight=cfg.targetTune.highOCWeight, ...
        lambdaWet=cfg.targetTune.lambdaWet, ...
        lambdaDry=cfg.targetTune.lambdaDry, ...
        lambdaOC1=lambdaOC1, ...
        lambdaOC2=lambdaOC2, ...
        lambdaOC3=lambdaOC3, ...
        lambdaSat=lambdaSat, ...
        lambdaReg=cfg.training.physics.lambdaReg, ...
        usePlateauAnchor=cfg.targetTune.usePlateauAnchor, ...
        lambdaPlateau=lambdaPlateau, ...
        freezeTrunk=cfg.targetTune.freezeTrunk);
    modelsOut{i} = ft.model;
end
end

function selection = select_best_ho_target_variant(ablationModelsFinetuned, ablationHoldoutFinetunedTable, cfg)
variantLabels = string(cfg.targetTune.hoSearchVariants(:));
allDisplay = string(ablationHoldoutFinetunedTable.DisplayName);
candidateIdx = find(ismember(allDisplay, variantLabels));
if isempty(candidateIdx)
    [~, idx] = min(ablationHoldoutFinetunedTable.RMSE);
    candidateIdx = idx;
end

bestIdx = candidateIdx(1);
bestVal = inf;
for ii = 1:numel(candidateIdx)
    idx = candidateIdx(ii);
    thisModel = ablationModelsFinetuned{idx};
    thisVal = thisModel.bestValRMSE;
    if thisVal < bestVal
        bestVal = thisVal;
        bestIdx = idx;
    end
end

pickedModel = ablationModelsFinetuned{bestIdx};
pickedModel.name = "HO_PINN_target_ft";
summaryTable = ablationHoldoutFinetunedTable(candidateIdx, :);
summaryTable.selected_by_val_rmse = false(height(summaryTable), 1);
selectedRow = find(string(summaryTable.DisplayName) == string(ablationHoldoutFinetunedTable.DisplayName(bestIdx)), 1, "first");
if ~isempty(selectedRow)
    summaryTable.selected_by_val_rmse(selectedRow) = true;
end

selection = struct();
selection.model = pickedModel;
selection.variantLabel = string(ablationHoldoutFinetunedTable.DisplayName(bestIdx));
selection.bestValidationRMSE = bestVal;
selection.summaryTable = summaryTable;
selection.sourceIndex = bestIdx;
end

function result = fine_tune_point_to_target(sourceModel, targetSplit, cfg, options)
arguments
    sourceModel struct
    targetSplit struct
    cfg struct
    options.modelName string = "PINN_target_ft"
    options.repeatRuns double = 3
    options.epochs double = 140
    options.learningRate double = 2e-4
end

bestMetric = inf;
bestResult = [];
summaryRows = table();
if isfield(sourceModel, "lossVariant") && ~isempty(sourceModel.lossVariant)
    targetLossVariant = string(sourceModel.lossVariant);
else
    targetLossVariant = string(cfg.training.point.lossVariant);
end
for r = 1:options.repeatRuns
    runName = options.modelName + "_run" + string(r);
    candidate = train_point_pinn_baseline(struct(), cfg, ...
        modelName=runName, ...
        lossVariant=targetLossVariant, ...
        epochs=options.epochs, ...
        learningRate=options.learningRate, ...
        seedOverride=cfg.seed + 1200 + r - 1, ...
        initParams=sourceModel.params, ...
        customTrainData=targetSplit.trainData, ...
        customValData=targetSplit.valData);
    metric = candidate.model.bestValRMSE;
    summaryRows = [summaryRows; table(string(options.modelName), r, metric, 'VariableNames', {'model_name','run_index','validation_rmse'})]; %#ok<AGROW>
    if metric < bestMetric
        bestMetric = metric;
        bestResult = candidate;
    end
end
bestResult.model.name = options.modelName;
result = bestResult;
result.repeatSummary = summaryRows;
end

function model = fine_tune_retc_to_target(sourceModel, targetSplit, cfg, options)
arguments
    sourceModel struct
    targetSplit struct
    cfg struct
    options.modelName string = "VG_target_ft"
end

trainCurveTable = fit_vg_curve_table(targetSplit.trainData.curveTable, targetSplit.trainData.pointTable, cfg);
valCurveTable = fit_vg_curve_table(targetSplit.valData.curveTable, targetSplit.valData.pointTable, cfg);

trainMask = trainCurveTable.vg_fit_success;
valMask = valCurveTable.vg_fit_success;
if ~any(trainMask)
    error("VG target fine-tuning failed because no target-train curves produced valid VG fits.");
end

XTrain = normalize_minmax_apply(trainCurveTable{trainMask, cfg.soilFeatureColumns}, sourceModel.normStats);
thetaUpperTrain = trainCurveTable.theta_s_upper(trainMask);
thetaSratioTrain = min(0.99, max(1e-4, trainCurveTable.vg_theta_s(trainMask) ./ max(thetaUpperTrain, 1e-6)));
thetaRratioTrain = min(0.99, max(1e-4, trainCurveTable.vg_theta_r(trainMask) ./ max(trainCurveTable.vg_theta_s(trainMask), 1e-6)));
YTrain = [ ...
    log(thetaRratioTrain ./ (1 - thetaRratioTrain)), ...
    log(thetaSratioTrain ./ (1 - thetaSratioTrain)), ...
    log(max(trainCurveTable.vg_alpha(trainMask), 1e-6)), ...
    log(max(trainCurveTable.vg_n(trainMask) - 1, 1e-6))];

if any(valMask)
    XVal = normalize_minmax_apply(valCurveTable{valMask, cfg.soilFeatureColumns}, sourceModel.normStats);
    thetaUpperVal = valCurveTable.theta_s_upper(valMask);
    thetaSratioVal = min(0.99, max(1e-4, valCurveTable.vg_theta_s(valMask) ./ max(thetaUpperVal, 1e-6)));
    thetaRratioVal = min(0.99, max(1e-4, valCurveTable.vg_theta_r(valMask) ./ max(valCurveTable.vg_theta_s(valMask), 1e-6)));
    YVal = [ ...
        log(thetaRratioVal ./ (1 - thetaRratioVal)), ...
        log(thetaSratioVal ./ (1 - thetaSratioVal)), ...
        log(max(valCurveTable.vg_alpha(valMask), 1e-6)), ...
        log(max(valCurveTable.vg_n(valMask) - 1, 1e-6))];
else
    XVal = zeros(0, size(XTrain, 2));
    YVal = zeros(0, size(YTrain, 2));
end

W = ridge_regression_warmstart(XTrain, YTrain, cfg.model.retcRidge, sourceModel.W, cfg.targetTune.retcWarmLambda);
if isempty(XVal)
    valPred = apply_ridge_regression(XTrain, W);
    valRmse = sqrt(mean((valPred - YTrain).^2, 'all'));
else
    valPred = apply_ridge_regression(XVal, W);
    valRmse = sqrt(mean((valPred - YVal).^2, 'all'));
end

model = sourceModel;
model.name = options.modelName;
model.W = W;
model.bestValRMSE = valRmse;
end

function W = ridge_regression_warmstart(X, Y, lambda, W0, lambdaWarm)
X1 = [ones(size(X, 1), 1), X];
I = eye(size(X1, 2));
I(1,1) = 0;
A = X1' * X1 + lambda * I + lambdaWarm * I;
B = X1' * Y + lambdaWarm * W0;
W = A \ B;
end

function tbl = blacksoil_delta_table(sourceTbl, targetTbl)
sharedModels = string(sourceTbl.Model);
targetIdx = zeros(numel(sharedModels), 1);
for i = 1:numel(sharedModels)
    targetIdx(i) = find(string(targetTbl.Model) == sharedModels(i), 1, "first");
end
tbl = table(sharedModels, ...
    targetTbl.R2(targetIdx) - sourceTbl.R2, ...
    targetTbl.RMSE(targetIdx) - sourceTbl.RMSE, ...
    targetTbl.MAE(targetIdx) - sourceTbl.MAE, ...
    targetTbl.MAPE(targetIdx) - sourceTbl.MAPE, ...
    targetTbl.MBE(targetIdx) - sourceTbl.MBE, ...
    'VariableNames', {'Model','delta_R2','delta_RMSE','delta_MAE','delta_MAPE','delta_MBE'});
end

function tbl = build_target_repeat_summary(externalModelsFinetuned, ablationModelsFinetuned)
rows = table();
for i = 1:numel(externalModelsFinetuned)
    thisModel = externalModelsFinetuned{i};
    if isfield(thisModel, "bestValRMSE")
        rows = [rows; table("external", string(thisModel.name), thisModel.bestValRMSE, ...
            'VariableNames', {'group_name','model_name','best_validation_rmse'})]; %#ok<AGROW>
    end
end
for i = 1:numel(ablationModelsFinetuned)
    thisModel = ablationModelsFinetuned{i};
    if isfield(thisModel, "bestValRMSE")
        rows = [rows; table("ablation", string(thisModel.name), thisModel.bestValRMSE, ...
            'VariableNames', {'group_name','model_name','best_validation_rmse'})]; %#ok<AGROW>
    end
end
tbl = rows;
end

function outTable = evaluate_models_to_table(models, labels, displayNames, splitData, cfg)
rows = repmat(local_metric_row_template(), numel(models), 1);
for i = 1:numel(models)
    evalResult = evaluate_single_model(models{i}, splitData, cfg);
    rows(i) = local_fill_metric_row(rows(i), labels(i), displayNames(i), evalResult);
end
outTable = struct2table(rows);
end

function write_results_workbook(filePath, overallTable, highOCTable, idVar)
overallOut = table();
overallOut.(idVar) = overallTable.Model;
overallOut.display_name = overallTable.DisplayName;
overallOut.R2 = overallTable.R2;
overallOut.RMSE = overallTable.RMSE;
overallOut.MAE = overallTable.MAE;
overallOut.MAPE = overallTable.MAPE;
overallOut.MBE = overallTable.MBE;
overallOut.monotonicity_rate = overallTable.MonotonicityRate;
overallOut.parameter_validity_rate = overallTable.ParameterValidityRate;
overallOut.comments = repmat("Generated by single-file pipeline", height(overallOut), 1);

highOut = table();
highOut.(idVar) = highOCTable.Model;
highOut.display_name = highOCTable.DisplayName;
highOut.R2 = highOCTable.R2;
highOut.RMSE = highOCTable.RMSE;
highOut.MAE = highOCTable.MAE;
highOut.MAPE = highOCTable.MAPE;
highOut.MBE = highOCTable.MBE;
highOut.monotonicity_rate = highOCTable.MonotonicityRate;
highOut.parameter_validity_rate = highOCTable.ParameterValidityRate;
highOut.comments = repmat("Generated by single-file pipeline", height(highOut), 1);

defs = table( ...
    ["R2";"RMSE";"MAE";"MAPE";"MBE"], ...
    ["Coefficient of determination";"Root mean squared error";"Mean absolute error";"Mean absolute percentage error (%)";"Mean bias error"], ...
    'VariableNames', {'metric_name','description'});

write_tables_to_excel(filePath, {'overall_metrics','high_OC_subset_metrics','metric_definitions'}, {overallOut, highOut, defs});
end

function write_results_workbook_extended(filePath, metricTables, idVar)
sheetNames = { ...
    'test_overall_metrics', ...
    'test_wet_end_metrics', ...
    'test_dry_end_metrics', ...
    'test_high_OC_metrics', ...
    'test_high_OC_wet_metrics', ...
    'test_high_OC_dry_metrics', ...
    'val_overall_metrics', ...
    'val_wet_end_metrics', ...
    'val_dry_end_metrics', ...
    'val_high_OC_metrics', ...
    'val_high_OC_wet_metrics', ...
    'val_high_OC_dry_metrics', ...
    'metric_definitions'};

tablePayloads = { ...
    workbook_metric_table(metricTables.testOverall, idVar), ...
    workbook_metric_table(metricTables.testWet, idVar), ...
    workbook_metric_table(metricTables.testDry, idVar), ...
    workbook_metric_table(metricTables.testHighOCOverall, idVar), ...
    workbook_metric_table(metricTables.testHighOCWet, idVar), ...
    workbook_metric_table(metricTables.testHighOCDry, idVar), ...
    workbook_metric_table(metricTables.valOverall, idVar), ...
    workbook_metric_table(metricTables.valWet, idVar), ...
    workbook_metric_table(metricTables.valDry, idVar), ...
    workbook_metric_table(metricTables.valHighOCOverall, idVar), ...
    workbook_metric_table(metricTables.valHighOCWet, idVar), ...
    workbook_metric_table(metricTables.valHighOCDry, idVar), ...
    metric_definition_table_extended()};

write_tables_to_excel(filePath, sheetNames, tablePayloads);
end

function out = workbook_metric_table(inTable, idVar)
out = table();
out.(idVar) = inTable.Model;
out.display_name = inTable.DisplayName;
out.R2 = inTable.R2;
out.RMSE = inTable.RMSE;
out.MAE = inTable.MAE;
out.MAPE = inTable.MAPE;
out.MBE = inTable.MBE;
out.monotonicity_rate = inTable.MonotonicityRate;
out.theta_lt_zero_rate = inTable.ThetaLtZeroRate;
out.invalid_theta_rate = inTable.InvalidThetaRate;
out.parameter_validity_rate = inTable.ParameterValidityRate;
out.curve_rmse_mean = inTable.CurveRMSEMean;
out.curve_rmse_median = inTable.CurveRMSEMedian;
end

function defs = metric_definition_table_extended()
defs = table( ...
    ["R2";"RMSE";"MAE";"MAPE";"MBE";"MonotonicityRate";"ThetaLtZeroRate";"InvalidThetaRate";"ParameterValidityRate"], ...
    ["Coefficient of determination"; ...
     "Root mean squared error"; ...
     "Mean absolute error"; ...
     "Mean absolute percentage error (%)"; ...
     "Mean bias error"; ...
     "Monotonicity satisfaction rate"; ...
     "Fraction of predictions below zero"; ...
     "Fraction of invalid predictions"; ...
     "Fraction of physically valid parameter sets"], ...
    'VariableNames', {'metric_name','description'});
end

function packageInfo = generate_single_file_final_outputs(dataBundle, externalResults, ablationResults, measuredResults, cfg)
% MODEL-ONLY public release: write reproducibility tables and skip manuscript figure generation.
bestWorkbookPath = write_best_run_results_workbook(cfg, externalResults, ablationResults);
packageInfo = struct();
packageInfo.bestWorkbookPath = bestWorkbookPath;
packageInfo.note = "Model-only public release; manuscript figure-generation code is intentionally excluded.";
end

function dataBundle = prepare_gshp_dataset(cfg)
% PREPARE_GSHP_DATASET Read, clean, regroup and split the GSHP table.

rawTable = read_gshp_table(cfg);
cleanTable = clean_gshp_table(rawTable, cfg);
curveTable = build_curve_table_from_points(cleanTable, cfg);
[curveTableSplit, pointTableSplit, splitInfo] = split_by_layer_id(curveTable, cleanTable, cfg);

trainCurveMask = curveTableSplit.split == "train";
trainPointMask = pointTableSplit.split == "train";
normStats = struct();
normStats.curve = normalize_minmax_fit(curveTableSplit{trainCurveMask, cfg.soilFeatureColumns});
normStats.point = normalize_minmax_fit(pointTableSplit{trainPointMask, cfg.pointFeatureColumns});

curveTableSplit{:, "theta_s_upper"} = max(0, min(1, 1 - curveTableSplit.BD ./ cfg.physics.solidDensity));
pointTableSplit{:, "theta_s_upper"} = max(0, min(1, 1 - pointTableSplit.BD ./ cfg.physics.solidDensity));
curveTableSplit{:, "high_oc_threshold"} = cfg.split.highOCThreshold;
pointTableSplit{:, "high_oc_threshold"} = cfg.split.highOCThreshold;

writetable(pointTableSplit, cfg.processedPointCsv);
writetable(curveTableSplit, cfg.processedCurveCsv);
writetable(curveTableSplit(:, {'layer_id','split','is_high_oc'}), cfg.splitCurveCsv);
writetable(pointTableSplit(:, {'layer_id','split','pF','theta'}), cfg.splitPointCsv);
write_split_summary(curveTableSplit, pointTableSplit, splitInfo, cfg);

dataBundle = struct();
dataBundle.rawTable = rawTable;
dataBundle.pointTable = pointTableSplit;
dataBundle.curveTable = curveTableSplit;
dataBundle.splitInfo = splitInfo;
dataBundle.normStats = normStats;
dataBundle.cfgSnapshot = cfg;
end

function measuredBundle = prepare_measured_highoc_dataset(cfg, normStats)
% PREPARE_MEASURED_HIGHOC_DATASET Read the appended text_table as external High-OC test data.

tbl = read_measured_text_table(cfg);
tbl = clean_gshp_table(tbl, cfg);

curveTable = build_curve_table_from_points(tbl, cfg);
curveTable.split = repmat("measured_highoc", height(curveTable), 1);
curveTable.is_high_oc = true(height(curveTable), 1);
curveTable.source_db = repmat("Measured High-OC external set", height(curveTable), 1);
curveTable.reference = fillmissing(curveTable.reference, "constant", "Local measured black-soil dataset");
curveTable.DOIs_URLs = fillmissing(curveTable.DOIs_URLs, "constant", "");

tbl.split = repmat("measured_highoc", height(tbl), 1);
tbl.is_high_oc = true(height(tbl), 1);
tbl.source_db = repmat("Measured High-OC external set", height(tbl), 1);
tbl.reference = fillmissing(tbl.reference, "constant", "Local measured black-soil dataset");
tbl.DOIs_URLs = fillmissing(tbl.DOIs_URLs, "constant", "");
tbl.theta_s_upper = max(0, min(1, 1 - tbl.BD ./ cfg.physics.solidDensity));
curveTable.theta_s_upper = max(0, min(1, 1 - curveTable.BD ./ cfg.physics.solidDensity));

measuredData = build_curve_array_data(curveTable, tbl, "measured_highoc", normStats, cfg);
measuredData.highOCMask = true(measuredData.nCurves, 1);

measuredBundle = struct();
measuredBundle.pointTable = tbl;
measuredBundle.curveTable = curveTable;
measuredBundle.data = measuredData;
measuredBundle.identification = summarize_measured_dataset(tbl, curveTable);
end

function tbl = read_measured_text_table(cfg)
candidateFiles = { ...
    cfg.rawInputXlsx, ...
    fullfile('E:\小论文稿件\高有机质黑土的连续土壤水分特征曲线预测模型\数据', 'GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx'), ...
    fullfile('C:\Users\94340\Downloads', 'GSHP_formal_training_table_with_layer_id_plus_metadata.xlsx')};

selectedFile = "";
for i = 1:numel(candidateFiles)
    thisFile = candidateFiles{i};
    if ~isfile(thisFile)
        continue;
    end
    try
        sheets = sheetnames(thisFile);
        if any(string(sheets) == cfg.measuredSheetName)
            selectedFile = string(thisFile);
            break;
        end
    catch
    end
end

if strlength(selectedFile) == 0
    error("Measured external dataset requires a workbook version containing the text_table sheet.");
end

tbl = readtable(selectedFile, Sheet=cfg.measuredSheetName, TextType="string");
if isempty(tbl)
    error("The text_table sheet was found but is empty.");
end

requiredMeasuredCols = {'layer_id','longitude','latitude','Sand','Silt','Clay','OC','BD','pF','theta','method'};
missingCols = setdiff(requiredMeasuredCols, tbl.Properties.VariableNames);
if ~isempty(missingCols)
    error("text_table is missing required columns: %s", strjoin(missingCols, ", "));
end

tbl = tbl(:, requiredMeasuredCols);
tbl = add_missing_metadata_columns(tbl, cfg.metadataColumns);

layerIdStr = string(tbl.layer_id);
methodStr = string(tbl.method);
bqMask = startsWith(layerIdStr, "BQ-", IgnoreCase=true);
methodMask = strcmpi(strtrim(methodStr), "Centrifugation technique");
measuredMask = bqMask | methodMask;
tbl = tbl(measuredMask, :);

if isempty(tbl)
    error("No measured High-OC rows were detected in text_table.");
end
end

function tbl = add_missing_metadata_columns(tbl, metadataColumns)
for i = 1:numel(metadataColumns)
    col = metadataColumns{i};
    if ~ismember(col, tbl.Properties.VariableNames)
        tbl.(col) = strings(height(tbl), 1);
    end
end
end

function info = summarize_measured_dataset(pointTable, curveTable)
layerIdStr = string(pointTable.layer_id);
methodStr = string(pointTable.method);
info = struct();
info.totalRows = height(pointTable);
info.uniqueCurves = height(curveTable);
info.bqLikeRows = sum(startsWith(layerIdStr, "BQ-", IgnoreCase=true));
info.centrifugationRows = sum(strcmpi(strtrim(methodStr), "Centrifugation technique"));
info.layerIdList = unique(curveTable.layer_id, "stable");
end

function tbl = read_gshp_table(cfg)
if isfile(cfg.rawInputXlsx)
    try
        tbl = readtable(cfg.rawInputXlsx, Sheet=cfg.trainingSheetName, TextType="string");
    catch
        tbl = readtable(cfg.rawInputXlsx, TextType="string");
    end
    writetable(tbl, cfg.rawInputCsv);
elseif isfile(cfg.rawInputCsv)
    tbl = readtable(cfg.rawInputCsv, TextType="string");
else
    error("Neither GSHP csv nor xlsx file was found.");
end

missingCols = setdiff(cfg.requiredColumns, tbl.Properties.VariableNames);
if ~isempty(missingCols)
    error("Missing required columns: %s", strjoin(missingCols, ", "));
end

tbl = tbl(:, cfg.requiredColumns);
end

function tbl = clean_gshp_table(tbl, cfg)
numericCols = {'longitude','latitude','Sand','Silt','Clay','OC','BD','pF','theta'};
for i = 1:numel(numericCols)
    col = numericCols{i};
    if ~isnumeric(tbl.(col))
        tbl.(col) = parse_numeric_column(tbl.(col));
    end
end

tbl.layer_id = string(tbl.layer_id);
for i = 1:numel(cfg.metadataColumns)
    col = cfg.metadataColumns{i};
    tbl.(col) = string(tbl.(col));
end

requiredFinite = isfinite(tbl.Sand) & isfinite(tbl.Silt) & isfinite(tbl.Clay) & ...
    isfinite(tbl.OC) & isfinite(tbl.BD) & isfinite(tbl.pF) & isfinite(tbl.theta);
validMask = requiredFinite & ...
    tbl.Sand >= 0 & tbl.Sand <= 100 & ...
    tbl.Silt >= 0 & tbl.Silt <= 100 & ...
    tbl.Clay >= 0 & tbl.Clay <= 100 & ...
    tbl.BD >= cfg.cleaning.minBD & tbl.BD <= cfg.cleaning.maxBD & ...
    tbl.theta >= 0 & tbl.theta <= 1 & ...
    strlength(tbl.layer_id) > 0;

tbl = tbl(validMask, :);
tbl = sortrows(tbl, {'layer_id','pF'});
end

function x = parse_numeric_column(v)
if isnumeric(v)
    x = double(v);
elseif isstring(v) || ischar(v) || iscellstr(v) || iscell(v)
    x = str2double(string(v));
else
    x = double(v);
end
end

function curveTable = build_curve_table_from_points(pointTable, cfg)
[groupId, layerRows] = findgroups(pointTable(:, {'layer_id'}));
nCurves = height(layerRows);

curveTable = table();
curveTable.layer_id = layerRows.layer_id;
curveTable.longitude = splitapply(@mean, pointTable.longitude, groupId);
curveTable.latitude = splitapply(@mean, pointTable.latitude, groupId);
for i = 1:numel(cfg.soilFeatureColumns)
    col = cfg.soilFeatureColumns{i};
    curveTable.(col) = splitapply(@mean, pointTable.(col), groupId);
end
curveTable.point_count = splitapply(@numel, pointTable.theta, groupId);
curveTable.pF_min = splitapply(@min, pointTable.pF, groupId);
curveTable.pF_max = splitapply(@max, pointTable.pF, groupId);
curveTable.theta_mean = splitapply(@mean, pointTable.theta, groupId);
curveTable.method = splitapply(@(x) string(x(1)), pointTable.method, groupId);
curveTable.source_db = splitapply(@(x) string(x(1)), pointTable.source_db, groupId);
curveTable.reference = splitapply(@(x) string(x(1)), pointTable.reference, groupId);
curveTable.DOIs_URLs = splitapply(@(x) string(x(1)), pointTable.DOIs_URLs, groupId);
curveTable.is_high_oc = is_high_oc_mask(curveTable.OC, cfg);

curveTable = curveTable(curveTable.point_count >= 2, :);
if height(curveTable) ~= nCurves
    validIds = curveTable.layer_id;
    pointMask = ismember(pointTable.layer_id, validIds);
    pointTable = pointTable(pointMask, :); %#ok<NASGU>
end
end

function write_split_summary(curveTable, pointTable, splitInfo, cfg)
fid = fopen(cfg.splitSummaryTxt, 'w');
fprintf(fid, "GSHP processed split summary\n");
fprintf(fid, "Total points: %d\n", height(pointTable));
fprintf(fid, "Total curves: %d\n", height(curveTable));
fprintf(fid, "Train curves: %d\n", sum(curveTable.split == "train"));
fprintf(fid, "Validation curves: %d\n", sum(curveTable.split == "val"));
fprintf(fid, "Test curves: %d\n", sum(curveTable.split == "test"));
fprintf(fid, "High-OC definition: %s\n", high_oc_definition_string(cfg));
fprintf(fid, "Train high-OC curves: %d\n", sum(curveTable.split == "train" & curveTable.is_high_oc));
fprintf(fid, "Validation high-OC curves: %d\n", sum(curveTable.split == "val" & curveTable.is_high_oc));
fprintf(fid, "Test high-OC curves: %d\n", sum(curveTable.split == "test" & curveTable.is_high_oc));
fprintf(fid, "OC strata count: %d\n", splitInfo.numStrata);
fclose(fid);
end

function [curveTable, pointTable, info] = split_by_layer_id(curveTable, pointTable, cfg)
% SPLIT_BY_LAYER_ID Split strictly by unique layer_id and verify zero overlap.

rng(cfg.seed, "twister");

curveTable.is_high_oc = is_high_oc_mask(curveTable.OC, cfg);
ocEdges = unique(quantile(curveTable.OC, [0 0.33 0.66 1]));
if numel(ocEdges) < 3
    ocEdges = [-inf; median(curveTable.OC); inf];
else
    ocEdges(1) = -inf;
    ocEdges(end) = inf;
end
curveTable.stratum = discretize(curveTable.OC, ocEdges);

curveTable.split = strings(height(curveTable), 1);
strata = unique(curveTable.stratum);
for i = 1:numel(strata)
    idx = find(curveTable.stratum == strata(i));
    idx = idx(randperm(numel(idx)));
    n = numel(idx);
    nTrain = max(1, floor(n * cfg.split.trainRatio));
    nVal = max(1, floor(n * cfg.split.valRatio));
    nTest = n - nTrain - nVal;
    if nTest < 1
        nTest = 1;
        if nTrain > nVal
            nTrain = nTrain - 1;
        else
            nVal = max(1, nVal - 1);
        end
    end
    curveTable.split(idx(1:nTrain)) = "train";
    curveTable.split(idx(nTrain + 1:nTrain + nVal)) = "val";
    curveTable.split(idx(nTrain + nVal + 1:end)) = "test";
end

verify_no_layer_overlap(curveTable);

splitMap = curveTable(:, {'layer_id','split','is_high_oc'});
pointTable = innerjoin(pointTable, splitMap, Keys="layer_id");

info = struct();
info.numStrata = numel(strata);
info.ocEdges = ocEdges;
info.trainCurveCount = sum(curveTable.split == "train");
info.valCurveCount = sum(curveTable.split == "val");
info.testCurveCount = sum(curveTable.split == "test");
end

function verify_no_layer_overlap(curveTable)
% VERIFY_NO_LAYER_OVERLAP Stop if any layer_id leaks across splits.

trainIds = curveTable.layer_id(curveTable.split == "train");
valIds = curveTable.layer_id(curveTable.split == "val");
testIds = curveTable.layer_id(curveTable.split == "test");

if ~isempty(intersect(trainIds, valIds)) || ~isempty(intersect(trainIds, testIds)) || ~isempty(intersect(valIds, testIds))
    error("Layer leakage detected across train/validation/test splits.");
end
end

function stats = normalize_minmax_fit(X)
% NORMALIZE_MINMAX_FIT Fit [0,1] min-max normalization statistics.

stats = struct();
stats.min = min(X, [], 1);
stats.max = max(X, [], 1);
stats.scale = stats.max - stats.min;
stats.scale(stats.scale == 0) = 1;
end

function XNorm = normalize_minmax_apply(X, stats)
% NORMALIZE_MINMAX_APPLY Apply min-max normalization with fitted stats.

XNorm = (X - stats.min) ./ stats.scale;
XNorm = max(0, min(1, XNorm));
end

function XNorm = normalize_minmax_apply_noclip(X, stats)
% NORMALIZE_MINMAX_APPLY_NOCLIP Apply min-max normalization without clipping.

XNorm = (X - stats.min) ./ stats.scale;
end

function mask = is_high_oc_mask(ocValues, cfg)
% IS_HIGH_OC_MASK Apply the configured high-OC threshold logic.

threshold = cfg.split.highOCThreshold;
if isfield(cfg.split, "highOCInclusive") && cfg.split.highOCInclusive
    mask = ocValues >= threshold;
else
    mask = ocValues > threshold;
end
end

function label = high_oc_definition_string(cfg)
% HIGH_OC_DEFINITION_STRING Return a readable high-OC rule label.

if isfield(cfg.split, "highOCInclusive") && cfg.split.highOCInclusive
    op = ">=";
else
    op = ">";
end
label = sprintf("OC %s %.2f", op, cfg.split.highOCThreshold);
end

function splitData = build_curve_array_data(curveTable, pointTable, splitLabel, normStats, cfg)
% BUILD_CURVE_ARRAY_DATA Convert split tables into array-based datasets.

curveMask = curveTable.split == string(splitLabel);
pointMask = pointTable.split == string(splitLabel);

splitCurves = curveTable(curveMask, :);
splitPoints = pointTable(pointMask, :);

nCurves = height(splitCurves);
curveIds = splitCurves.layer_id;
if nCurves == 0
    splitData = struct();
    splitData.name = string(splitLabel);
    splitData.curveTable = splitCurves;
    splitData.pointTable = splitPoints;
    splitData.nCurves = 0;
    splitData.maxPoints = 0;
    splitData.XCurveRaw = zeros(0, numel(cfg.soilFeatureColumns));
    splitData.XCurveNorm = zeros(0, numel(cfg.soilFeatureColumns));
    splitData.thetaSUpper = zeros(0, 1);
    splitData.highOCMask = false(0, 1);
    splitData.pFMatrix = zeros(0, 0);
    splitData.thetaMatrix = zeros(0, 0);
    splitData.thetaUpperMatrix = zeros(0, 0);
    splitData.maskMatrix = false(0, 0);
    splitData.plateauAnchorMaskMatrix = false(0, 0);
    splitData.plateauThetaObserved = zeros(0, 1);
    splitData.plateauHasAnchor = false(0, 1);
    splitData.pFRange = [NaN, NaN];
    splitData.curveIndexByPoint = zeros(0, 1);
    splitData.XPointRaw = zeros(0, numel(cfg.pointFeatureColumns));
    splitData.XPointNorm = zeros(0, numel(cfg.pointFeatureColumns));
    splitData.pointTheta = zeros(0, 1);
    splitData.pointThetaUpper = zeros(0, 1);
    splitData.layerIds = strings(0, 1);
    splitData.normStats = normStats;
    return;
end

pointCounts = splitCurves.point_count;
maxPoints = max(pointCounts);

pFMatrix = nan(nCurves, maxPoints);
thetaMatrix = nan(nCurves, maxPoints);
maskMatrix = false(nCurves, maxPoints);
plateauAnchorMaskMatrix = false(nCurves, maxPoints);
plateauThetaObserved = zeros(nCurves, 1);
plateauHasAnchor = false(nCurves, 1);
thetaUpperMatrix = nan(nCurves, maxPoints);
curveIndexByPoint = zeros(height(splitPoints), 1);

for i = 1:nCurves
    localMask = splitPoints.layer_id == curveIds(i);
    localPoints = splitPoints(localMask, :);
    [pfSorted, order] = sort(localPoints.pF);
    thetaSorted = localPoints.theta(order);
    thetaUpperSorted = localPoints.theta_s_upper(order);
    k = numel(pfSorted);
    pFMatrix(i, 1:k) = pfSorted;
    thetaMatrix(i, 1:k) = thetaSorted;
    thetaUpperMatrix(i, 1:k) = thetaUpperSorted;
    maskMatrix(i, 1:k) = true;
    if k > 0
        anchorMaskLocal = pfSorted <= (pfSorted(1) + cfg.targetTune.plateauPFWindow);
        if sum(anchorMaskLocal) > cfg.targetTune.plateauTopK
            firstIdx = find(anchorMaskLocal);
            anchorMaskLocal(firstIdx(cfg.targetTune.plateauTopK+1:end)) = false;
        end
        plateauAnchorMaskMatrix(i, 1:k) = anchorMaskLocal;
        plateauThetaObserved(i) = max(thetaSorted(anchorMaskLocal));
        plateauHasAnchor(i) = any(anchorMaskLocal);
    end
    curveIndexByPoint(localMask) = i;
end

splitData = struct();
splitData.name = string(splitLabel);
splitData.curveTable = splitCurves;
splitData.pointTable = splitPoints;
splitData.nCurves = nCurves;
splitData.maxPoints = maxPoints;
splitData.XCurveRaw = splitCurves{:, cfg.soilFeatureColumns};
splitData.XCurveNorm = normalize_minmax_apply(splitData.XCurveRaw, normStats.curve);
splitData.thetaSUpper = splitCurves.theta_s_upper;
splitData.highOCMask = is_high_oc_mask(splitCurves.OC, cfg);
splitData.pFMatrix = pFMatrix;
splitData.thetaMatrix = thetaMatrix;
splitData.thetaUpperMatrix = thetaUpperMatrix;
splitData.maskMatrix = maskMatrix;
splitData.plateauAnchorMaskMatrix = plateauAnchorMaskMatrix;
splitData.plateauThetaObserved = plateauThetaObserved;
splitData.plateauHasAnchor = plateauHasAnchor;
splitData.pFRange = [min(splitPoints.pF), max(splitPoints.pF)];
splitData.curveIndexByPoint = curveIndexByPoint;
splitData.XPointRaw = splitPoints{:, cfg.pointFeatureColumns};
splitData.XPointNorm = normalize_minmax_apply(splitData.XPointRaw, normStats.point);
splitData.pointTheta = splitPoints.theta;
splitData.pointThetaUpper = splitPoints.theta_s_upper;
splitData.layerIds = curveIds;
splitData.normStats = normStats;
end

function residualSets = build_wrr_residual_sets(trainData, cfg)
% BUILD_WRR_RESIDUAL_SETS Construct the four residual-point sets used in WRR Equation (4).

baseRaw = trainData.XPointRaw;
if isempty(baseRaw)
    residualSets = struct("set1Raw", [], "set1Norm", [], "set2Raw", [], "set2Norm", [], ...
        "set3Raw", [], "set3Norm", [], "set4Raw", [], "set4Norm", []);
    return;
end

nBase = size(baseRaw, 1);
sample_rows = @(n) baseRaw(randi(nBase, n, 1), :);

set1Raw = sample_rows(cfg.training.point.S1);
set1Raw(:, 6) = cfg.training.point.dryLinearityPFRange(1) + ...
    rand(cfg.training.point.S1, 1) * diff(cfg.training.point.dryLinearityPFRange);

set2Raw = sample_rows(cfg.training.point.S2);
set2Raw(:, 6) = cfg.training.point.pF0Lower;

set3Raw = sample_rows(cfg.training.point.S3);
set3Raw(:, 6) = cfg.training.point.pF0Upper;

set4Raw = sample_rows(cfg.training.point.S4);
set4Raw(:, 6) = cfg.training.point.airEntryPFRange(1) + ...
    rand(cfg.training.point.S4, 1) * diff(cfg.training.point.airEntryPFRange);

residualSets = struct();
residualSets.set1Raw = set1Raw;
residualSets.set1Norm = normalize_minmax_apply_noclip(set1Raw, trainData.normStats.point);
residualSets.set2Raw = set2Raw;
residualSets.set2Norm = normalize_minmax_apply_noclip(set2Raw, trainData.normStats.point);
residualSets.set3Raw = set3Raw;
residualSets.set3Norm = normalize_minmax_apply_noclip(set3Raw, trainData.normStats.point);
residualSets.set4Raw = set4Raw;
residualSets.set4Norm = normalize_minmax_apply_noclip(set4Raw, trainData.normStats.point);
end

function textureClass = derive_texture_class_usda(sand, silt, clay)
% DERIVE_TEXTURE_CLASS_USDA Approximate USDA textural class labels.

sand = double(sand(:));
silt = double(silt(:));
clay = double(clay(:));
n = numel(sand);
textureClass = repmat("Unclassified", n, 1);

for i = 1:n
    sa = sand(i);
    si = silt(i);
    cl = clay(i);

    total = sa + si + cl;
    if ~isfinite(total) || total <= 0
        textureClass(i) = "Unclassified";
        continue;
    end

    sa = 100 * sa / total;
    si = 100 * si / total;
    cl = 100 * cl / total;

    if (si + 1.5 * cl) < 15
        textureClass(i) = "Sand";
    elseif (si + 1.5 * cl) >= 15 && (si + 2 * cl) < 30
        textureClass(i) = "Loamy sand";
    elseif (cl >= 7 && cl < 20 && sa > 52 && si < 50) || ...
            (cl < 7 && si < 50 && sa >= 43 && sa <= 85)
        textureClass(i) = "Sandy loam";
    elseif cl >= 7 && cl < 27 && si >= 28 && si < 50 && sa <= 52
        textureClass(i) = "Loam";
    elseif (si >= 50 && cl < 27) || (si >= 50 && si < 80 && cl < 12)
        textureClass(i) = "Silt loam";
    elseif si >= 80 && cl < 12
        textureClass(i) = "Silt";
    elseif cl >= 20 && cl < 35 && sa > 45
        textureClass(i) = "Sandy clay loam";
    elseif cl >= 27 && cl < 40 && sa > 20 && sa <= 45
        textureClass(i) = "Clay loam";
    elseif cl >= 27 && cl < 40 && sa <= 20
        textureClass(i) = "Silty clay loam";
    elseif cl >= 35 && sa > 45
        textureClass(i) = "Sandy clay";
    elseif cl >= 40 && si >= 40
        textureClass(i) = "Silty clay";
    elseif cl >= 40
        textureClass(i) = "Clay";
    end
end
end

function [paramRow, success] = fit_vg_curve_single(pF, theta, bd, cfg)
% FIT_VG_CURVE_SINGLE Fit VG parameters to one observed curve using fminsearch.

pF = pF(:);
theta = theta(:);
thetaUpper = max(0.05, min(0.95, 1 - bd / cfg.physics.solidDensity));

thetaS0 = min(thetaUpper, max(theta));
thetaR0 = max(0, min(thetaS0 * 0.8, min(theta)));
alpha0 = 1e-2;
n0 = 1.5;
z0 = [logit_bound(thetaR0 / max(thetaS0, 1e-6), 1e-4, 0.95), ...
      logit_bound(thetaS0 / max(thetaUpper, 1e-6), 1e-4, 0.98), ...
      log(max(alpha0, 1e-6)), ...
      log(max(n0 - 1, 1e-6))];

obj = @(z) mean((theta - vg_from_z(z, pF, thetaUpper, cfg)).^2);
opts = optimset('Display', 'off', 'MaxIter', 600, 'MaxFunEvals', 1200);

try
    zHat = fminsearch(obj, z0, opts);
    thetaHat = vg_from_z(zHat, pF, thetaUpper, cfg);
    success = all(isfinite(thetaHat));
    [thetaR, thetaS, alpha, n] = unpack_z(zHat, thetaUpper, cfg);
catch
    success = false;
    thetaR = NaN; thetaS = NaN; alpha = NaN; n = NaN;
end

paramRow = struct();
paramRow.theta_r = thetaR;
paramRow.theta_s = thetaS;
paramRow.alpha = alpha;
paramRow.n = n;
end

function theta = vg_from_z(z, pF, thetaUpper, cfg)
[thetaR, thetaS, alpha, n] = unpack_z(z, thetaUpper, cfg);
m = 1 - 1 / n;
h = 10 .^ pF;
theta = thetaR + (thetaS - thetaR) ./ ((1 + (alpha .* h) .^ n) .^ m);
end

function [thetaR, thetaS, alpha, n] = unpack_z(z, thetaUpper, cfg)
thetaS = thetaUpper ./ (1 + exp(-z(2)));
thetaR = thetaS .* (1 ./ (1 + exp(-z(1)))) * 0.98;
alpha = exp(z(3)) + cfg.physics.alphaEpsilon;
n = 1 + exp(z(4)) + cfg.physics.nEpsilon;
end

function z = logit_bound(x, lo, hi)
x = min(hi, max(lo, x));
x = (x - lo) / (hi - lo);
z = log(x / (1 - x));
end

function curveTable = fit_vg_curve_table(curveTable, pointTable, cfg)
% FIT_VG_CURVE_TABLE Fit VG parameters curve-by-curve from observed points.

curveTable.vg_theta_r = NaN(height(curveTable), 1);
curveTable.vg_theta_s = NaN(height(curveTable), 1);
curveTable.vg_alpha = NaN(height(curveTable), 1);
curveTable.vg_n = NaN(height(curveTable), 1);
curveTable.vg_fit_success = false(height(curveTable), 1);

for i = 1:height(curveTable)
    mask = pointTable.layer_id == curveTable.layer_id(i);
    [paramRow, success] = fit_vg_curve_single(pointTable.pF(mask), pointTable.theta(mask), curveTable.BD(i), cfg);
    curveTable.vg_theta_r(i) = paramRow.theta_r;
    curveTable.vg_theta_s(i) = paramRow.theta_s;
    curveTable.vg_alpha(i) = paramRow.alpha;
    curveTable.vg_n(i) = paramRow.n;
    curveTable.vg_fit_success(i) = success;
end
end

function params = init_model_params(modelKind, useDualBranch, seed)
% INIT_MODEL_PARAMS Initialize learnable parameters for a given model.

rng(seed, "twister");

switch string(modelKind)
    case "parametric"
        if useDualBranch
            params.branchA.W1 = glorot([128, 4]); params.branchA.b1 = zeros_dl([128,1]);
            params.branchA.W2 = glorot([128, 128]); params.branchA.b2 = zeros_dl([128,1]);
            params.branchA.W3 = glorot([64, 128]); params.branchA.b3 = zeros_dl([64,1]);
            params.branchB.W1 = glorot([64, 2]); params.branchB.b1 = zeros_dl([64,1]);
            params.branchB.W2 = glorot([32, 64]); params.branchB.b2 = zeros_dl([32,1]);
            params.head.W1 = glorot([32, 96]); params.head.b1 = zeros_dl([32,1]);
            params.head.W2 = glorot([4, 32]); params.head.b2 = zeros_dl([4,1]);
        else
            params.net.W1 = glorot([128, 5]); params.net.b1 = zeros_dl([128,1]);
            params.net.W2 = glorot([128, 128]); params.net.b2 = zeros_dl([128,1]);
            params.net.W3 = glorot([64, 128]); params.net.b3 = zeros_dl([64,1]);
            params.net.W4 = glorot([32, 64]); params.net.b4 = zeros_dl([32,1]);
            params.net.W5 = glorot([4, 32]); params.net.b5 = zeros_dl([4,1]);
        end

    case "point"
        params.net.W1 = glorot([128, 6]); params.net.b1 = zeros_dl([128,1]);
        params.net.W2 = glorot([128, 128]); params.net.b2 = zeros_dl([128,1]);
        params.net.W3 = glorot([64, 128]); params.net.b3 = zeros_dl([64,1]);
        params.net.W4 = glorot([32, 64]); params.net.b4 = zeros_dl([32,1]);
        params.net.W5 = glorot([1, 32]); params.net.b5 = zeros_dl([1,1]);

    otherwise
        error("Unsupported model kind: %s", string(modelKind));
end
end

function x = glorot(sz)
limit = sqrt(6 / (sz(1) + sz(2)));
x = dlarray(single((rand(sz) * 2 - 1) * limit));
end

function z = zeros_dl(sz)
z = dlarray(zeros(sz, "single"));
end

function paramStruct = forward_parametric_model(params, XNorm, XRaw, cfg, useDualBranch)
% FORWARD_PARAMETRIC_MODEL Predict physically valid VG parameters.

if ~isa(XNorm, "dlarray")
    XNorm = dlarray(single(XNorm'));
end
if ~isa(XRaw, "dlarray")
    XRaw = dlarray(single(XRaw'));
end

if useDualBranch
    xa = XNorm([1,2,3,5], :);
    xb = XNorm([4,5], :);
    fa = tanh(params.branchA.W1 * xa + params.branchA.b1);
    fa = tanh(params.branchA.W2 * fa + params.branchA.b2);
    fa = tanh(params.branchA.W3 * fa + params.branchA.b3);
    fb = tanh(params.branchB.W1 * xb + params.branchB.b1);
    fb = tanh(params.branchB.W2 * fb + params.branchB.b2);
    z = params.head.W2 * tanh(params.head.W1 * [fa; fb] + params.head.b1) + params.head.b2;
else
    hidden = tanh(params.net.W1 * XNorm + params.net.b1);
    hidden = tanh(params.net.W2 * hidden + params.net.b2);
    hidden = tanh(params.net.W3 * hidden + params.net.b3);
    hidden = tanh(params.net.W4 * hidden + params.net.b4);
    z = params.net.W5 * hidden + params.net.b5;
end

thetaUpper = max(0, min(1, 1 - XRaw(5, :) ./ cfg.physics.solidDensity));
thetaS = thetaUpper .* sigmoid(z(2, :));
thetaR = thetaS .* sigmoid(z(1, :)) * 0.98;
alpha = softplus(z(3, :)) + cfg.physics.alphaEpsilon;
n = 1 + softplus(z(4, :)) + cfg.physics.nEpsilon;
m = 1 - 1 ./ n;

paramStruct = struct();
paramStruct.theta_r = thetaR;
paramStruct.theta_s = thetaS;
paramStruct.theta_s_upper = thetaUpper;
paramStruct.alpha = alpha;
paramStruct.n = n;
paramStruct.m = m;
end

function y = sigmoid(x)
y = 1 ./ (1 + exp(-x));
end

function y = softplus(x)
y = log(1 + exp(-abs(x))) + max(x, 0);
end

function theta = vg_curve_eval(paramStruct, pF)
% VG_CURVE_EVAL Evaluate van Genuchten SWRC at the requested pF values.

if ~isa(pF, "dlarray")
    pF = dlarray(single(pF));
end

h = 10 .^ pF;
theta = paramStruct.theta_r + ...
    (paramStruct.theta_s - paramStruct.theta_r) ./ ((1 + (paramStruct.alpha .* h) .^ paramStruct.n) .^ paramStruct.m);
end

function y = forward_point_model(params, XNorm)
% FORWARD_POINT_MODEL Forward pass for the pointwise PINN baseline.

if ~isa(XNorm, "dlarray")
    XNorm = dlarray(single(XNorm'));
end

hidden = tanh(params.net.W1 * XNorm + params.net.b1);
hidden = tanh(params.net.W2 * hidden + params.net.b2);
hidden = tanh(params.net.W3 * hidden + params.net.b3);
hidden = tanh(params.net.W4 * hidden + params.net.b4);
y = params.net.W5 * hidden + params.net.b5;
end

function [dthetaDpF, thetaPred] = point_first_derivative_pf(params, XNorm, pfScale)
% POINT_FIRST_DERIVATIVE_PF First derivative of theta_hat with respect to pF using finite differences.

if isa(XNorm, "dlarray")
    XBase = double(extractdata(XNorm))';
else
    XBase = double(XNorm);
end

stepRaw = 1e-3;
stepNorm = stepRaw ./ max(double(pfScale), eps);
XPlus = XBase;
XPlus(:, 6) = XPlus(:, 6) + stepNorm;

thetaPred = forward_point_model(params, dlarray(single(XBase')));
thetaPlus = forward_point_model(params, dlarray(single(XPlus')));
dthetaDpF = (thetaPlus - thetaPred) ./ stepRaw;
end

function [d2thetaDpF2, dthetaDpF, thetaPred] = point_second_derivative_pf(params, XNorm, pfScale)
% POINT_SECOND_DERIVATIVE_PF Second derivative of theta_hat with respect to pF using central finite differences.

if isa(XNorm, "dlarray")
    XBase = double(extractdata(XNorm))';
else
    XBase = double(XNorm);
end

stepRaw = 1e-3;
stepNorm = stepRaw ./ max(double(pfScale), eps);
XPlus = XBase;
XMinus = XBase;
XPlus(:, 6) = XPlus(:, 6) + stepNorm;
XMinus(:, 6) = XMinus(:, 6) - stepNorm;

thetaPred = forward_point_model(params, dlarray(single(XBase')));
thetaPlus = forward_point_model(params, dlarray(single(XPlus')));
thetaMinus = forward_point_model(params, dlarray(single(XMinus')));
dthetaDpF = (thetaPlus - thetaMinus) ./ (2 * stepRaw);
d2thetaDpF2 = (thetaPlus - 2 * thetaPred + thetaMinus) ./ (stepRaw ^ 2);
end

function reg = recursive_l2(params)
% RECURSIVE_L2 Sum of squared parameters over a nested struct.

reg = dlarray(single(0));
fields = fieldnames(params);
for i = 1:numel(fields)
    item = params.(fields{i});
    if isstruct(item)
        reg = reg + recursive_l2(item);
    else
        reg = reg + sum(item.^2, "all");
    end
end
end

function loss = huber_loss_vec(residual, delta)
% HUBER_LOSS_VEC Elementwise Huber loss.

if nargin < 2 || isempty(delta)
    delta = 0.03;
end

absResidual = abs(residual);
quadraticMask = absResidual <= delta;
quadratic = 0.5 * residual.^2;
linear = delta * (absResidual - 0.5 * delta);
loss = quadraticMask .* quadratic + (~quadraticMask) .* linear;
end

function [params, avgGrad, avgSqGrad] = adam_update_struct(params, grads, avgGrad, avgSqGrad, iteration, lr, beta1, beta2, epsilon)
% ADAM_UPDATE_STRUCT Recursive Adam update over nested structs.

fields = fieldnames(params);
for i = 1:numel(fields)
    key = fields{i};
    if isstruct(params.(key))
        [params.(key), avgGrad.(key), avgSqGrad.(key)] = adam_update_struct( ...
            params.(key), grads.(key), avgGrad.(key), avgSqGrad.(key), ...
            iteration, lr, beta1, beta2, epsilon);
    else
        g = grads.(key);
        avgGrad.(key) = beta1 * avgGrad.(key) + (1 - beta1) * g;
        avgSqGrad.(key) = beta2 * avgSqGrad.(key) + (1 - beta2) * (g .* g);
        avgGradHat = avgGrad.(key) ./ (1 - beta1^iteration);
        avgSqGradHat = avgSqGrad.(key) ./ (1 - beta2^iteration);
        params.(key) = params.(key) - lr * avgGradHat ./ (sqrt(avgSqGradHat) + epsilon);
    end
end
end

function [lossValue, components] = loss_parametric_swrc(params, trainData, cfg, options, stageName)
% LOSS_PARAMETRIC_SWRC Loss for the curve-level HO-PINN parametric model.

XNorm = trainData.XCurveNorm;
XRaw = trainData.XCurveRaw;
mask = dlarray(single(trainData.maskMatrix));
thetaObsRaw = trainData.thetaMatrix;
pFRaw = trainData.pFMatrix;
thetaObsRaw(~trainData.maskMatrix) = 0;
pFRaw(~trainData.maskMatrix) = trainData.pFRange(1);
thetaObs = dlarray(single(thetaObsRaw));
pF = dlarray(single(pFRaw));

pred = forward_parametric_model(params, XNorm, XRaw, cfg, options.useDualBranch);
thetaPred = vg_curve_eval(pred, pF');
thetaPred = thetaPred';

curveWeights = ones(trainData.nCurves, 1, "single");
if options.useHighOCEnhancement && strcmp(stageName, "stage2")
    curveWeights(trainData.highOCMask) = options.highOCWeight;
end
curveWeightsDl = dlarray(curveWeights);

huberMat = huber_loss_vec(thetaPred - thetaObs, cfg.training.deltaHuber) .* mask;
if options.useSplitDataLoss
    wetMaskMat = mask .* dlarray(single(trainData.pFMatrix <= cfg.physics.wetDrySplitPF));
    dryMaskMat = mask .* dlarray(single(trainData.pFMatrix > cfg.physics.wetDrySplitPF));
    wetCounts = sum(wetMaskMat, 2);
    dryCounts = sum(dryMaskMat, 2);
    wetLossByCurve = sum(huberMat .* wetMaskMat, 2) ./ max(wetCounts, 1);
    dryLossByCurve = sum(huberMat .* dryMaskMat, 2) ./ max(dryCounts, 1);
    wetLossByCurve = wetLossByCurve .* dlarray(single(wetCounts > 0));
    dryLossByCurve = dryLossByCurve .* dlarray(single(dryCounts > 0));
    curveDataLoss = options.lambdaWet * wetLossByCurve + options.lambdaDry * dryLossByCurve;
    L_dataWet = sum(curveWeightsDl .* wetLossByCurve, "all") / max(sum(curveWeightsDl .* dlarray(single(wetCounts > 0)), "all"), eps('single'));
    L_dataDry = sum(curveWeightsDl .* dryLossByCurve, "all") / max(sum(curveWeightsDl .* dlarray(single(dryCounts > 0)), "all"), eps('single'));
else
    curvePointCounts = sum(mask, 2) + eps('single');
    curveDataLoss = sum(huberMat, 2) ./ curvePointCounts;
    L_dataWet = dlarray(single(NaN));
    L_dataDry = dlarray(single(NaN));
end
L_data = sum(curveWeightsDl .* curveDataLoss, "all") / sum(curveWeightsDl, "all");

L_oc1 = dlarray(single(0));
L_oc2 = dlarray(single(0));
L_oc3 = dlarray(single(0));
L_sat = dlarray(single(0));
L_plateau = dlarray(single(0));
if options.usePhysics && strcmp(stageName, "stage2")
    XRawPlus = XRaw;
    XRawPlus(:, 4) = XRawPlus(:, 4) + cfg.physics.ocStep;
    XNormPlus = normalize_minmax_apply(XRawPlus, trainData.normStats.curve);
    predPlus = forward_parametric_model(params, XNormPlus, XRawPlus, cfg, options.useDualBranch);
    L_oc1 = mean(max(0, pred.theta_s - predPlus.theta_s).^2, "all");
    L_oc2 = mean(max(0, predPlus.alpha - pred.alpha).^2, "all");

    highIdx = find(trainData.highOCMask);
    if ~isempty(highIdx)
        L_oc3 = mean(max(0, cfg.physics.betaOC3 * pred.theta_s_upper(highIdx) - pred.theta_s(highIdx)).^2, "all");
    end

    wetPfLo = trainData.pFRange(1);
    wetPfHi = min(trainData.pFRange(2), cfg.physics.wetPFMax);
    if isfinite(wetPfLo) && isfinite(wetPfHi) && wetPfHi > wetPfLo + 1e-6
        wetPfGrid = linspace(wetPfLo, wetPfHi, cfg.physics.wetSlopeGridCount);
        wetPfMat = dlarray(single(repmat(wetPfGrid(:), 1, trainData.nCurves)));
        thetaWetGrid = vg_curve_eval(pred, wetPfMat);
        dPf = diff(wetPfGrid(:));
        dTheta = thetaWetGrid(2:end, :) - thetaWetGrid(1:end-1, :);
        slopeWet = dTheta ./ dlarray(single(repmat(dPf, 1, trainData.nCurves)));
        L_sat = mean(slopeWet.^2, "all");
    end
end

if options.usePlateauAnchor && strcmp(stageName, "stage2") && isfield(trainData, "plateauHasAnchor")
    plateauHasAnchor = dlarray(single(trainData.plateauHasAnchor));
    if any(trainData.plateauHasAnchor)
        thetaWetObs = dlarray(single(trainData.plateauThetaObserved));
        plateauGap = max(0, thetaWetObs - pred.theta_s).^2;
        L_plateau = sum(curveWeightsDl .* plateauGap .* plateauHasAnchor, "all") / ...
            max(sum(curveWeightsDl .* plateauHasAnchor, "all"), eps('single'));
    end
end

L_reg = recursive_l2(params);
lossValue = L_data + ...
    options.lambdaOC1 * L_oc1 + ...
    options.lambdaOC2 * L_oc2 + ...
    options.lambdaOC3 * L_oc3 + ...
    options.lambdaSat * L_sat + ...
    options.lambdaPlateau * L_plateau + ...
    options.lambdaReg * L_reg;

components = struct();
components.data = L_data;
components.dataWet = L_dataWet;
components.dataDry = L_dataDry;
components.oc = L_oc1 + L_oc2 + L_oc3;
components.sat = L_sat;
components.plateau = L_plateau;
components.reg = L_reg;
end

function [lossValue, components] = loss_point_pinn(params, trainData, cfg, options)
% LOSS_POINT_PINN Loss for the pointwise WRR-style PINN baseline.

variant = local_get_option(options, "lossVariant", cfg.training.point.lossVariant);
switch string(variant)
    case "equation4_strict"
        [lossValue, components] = loss_point_pinn_equation4(params, trainData, cfg);
    otherwise
        [lossValue, components] = loss_point_pinn_simplified(params, trainData, cfg);
end
end

function [lossValue, components] = loss_point_pinn_simplified(params, trainData, cfg)
X = dlarray(single(trainData.XPointNorm'));
y = dlarray(single(trainData.pointTheta'));
thetaUpper = dlarray(single(trainData.pointThetaUpper'));
yPred = forward_point_model(params, X);

L_data = mean(huber_loss_vec(yPred - y, cfg.training.deltaHuber), "all");

XPlus = trainData.XPointNorm;
pfScale = max(max(trainData.XPointRaw(:, 6)) - min(trainData.XPointRaw(:, 6)), eps);
XPlus(:, 6) = min(1, XPlus(:, 6) + cfg.training.point.epsPF / pfScale);
yPlus = forward_point_model(params, dlarray(single(XPlus')));
L_mono = mean(max(0, yPlus - yPred).^2, "all");

L_bound = mean(max(0, -yPred).^2 + max(0, yPred - thetaUpper).^2, "all");

wetMask = trainData.XPointRaw(:, 6) <= cfg.physics.wetPFMax;
if any(wetMask)
    XWet = trainData.XPointNorm(wetMask, :);
    XWetPlus = XWet;
    XWetPlus(:, 6) = min(1, XWetPlus(:, 6) + cfg.training.point.epsPF / pfScale);
    yWet = forward_point_model(params, dlarray(single(XWet')));
    yWetPlus = forward_point_model(params, dlarray(single(XWetPlus')));
    L_wet = mean(((yWetPlus - yWet) / cfg.training.point.epsPF).^2, "all");
else
    L_wet = dlarray(single(0));
end

L_reg = recursive_l2(params);
lossValue = L_data + ...
    cfg.training.point.lambdaMono * L_mono + ...
    cfg.training.point.lambdaBound * L_bound + ...
    cfg.training.point.lambdaWet * L_wet + ...
    cfg.training.point.lambdaReg * L_reg;

components = struct("wetData", L_data, "dryData", dlarray(single(NaN)), ...
    "physics1", L_mono, "physics2", L_bound, "physics3", L_wet, "physics4", L_reg);
end

function [lossValue, components] = loss_point_pinn_equation4(params, trainData, cfg)
X = dlarray(single(trainData.XPointNorm'));
y = dlarray(single(trainData.pointTheta'));
yPred = forward_point_model(params, X);
sqErr = (yPred - y).^2;

wetMask = dlarray(single((trainData.XPointRaw(:, 6) <= cfg.physics.wetDrySplitPF)'));
dryMask = dlarray(single((trainData.XPointRaw(:, 6) > cfg.physics.wetDrySplitPF)'));
Nwet = max(sum(wetMask, "all"), 1);
Ndry = max(sum(dryMask, "all"), 1);
L_wet = sum(sqErr .* wetMask, "all") / Nwet;
L_dry = sum(sqErr .* dryMask, "all") / Ndry;

pfScale = single(trainData.normStats.point.scale(6));
if pfScale == 0
    pfScale = 1;
end

sets = trainData.wrrResidualSets;
L_set1 = dlarray(single(0));
if ~isempty(sets.set1Norm)
    [d2thetaSet1, ~, ~] = point_second_derivative_pf(params, sets.set1Norm, pfScale);
    L_set1 = mean(abs(d2thetaSet1), "all");
end

L_set2 = dlarray(single(0));
if ~isempty(sets.set2Norm)
    thetaSet2 = forward_point_model(params, dlarray(single(sets.set2Norm')));
    zeroLike2 = dlarray(zeros(size(thetaSet2), "single"));
    L_set2 = mean(abs(min(thetaSet2, zeroLike2)), "all");
end

L_set3 = dlarray(single(0));
if ~isempty(sets.set3Norm)
    thetaSet3 = forward_point_model(params, dlarray(single(sets.set3Norm')));
    zeroLike3 = dlarray(zeros(size(thetaSet3), "single"));
    L_set3 = mean(abs(max(thetaSet3, zeroLike3)), "all");
end

L_set4 = dlarray(single(0));
if ~isempty(sets.set4Norm)
    [dthetaSet4, ~] = point_first_derivative_pf(params, sets.set4Norm, pfScale);
    L_set4 = mean(abs(dthetaSet4), "all");
end

lossValue = ...
    cfg.training.point.lambda1 * L_wet + ...
    cfg.training.point.lambda2 * L_dry + ...
    cfg.training.point.lambda3 * L_set1 + ...
    cfg.training.point.lambda4 * L_set2 + ...
    cfg.training.point.lambda5 * L_set3 + ...
    cfg.training.point.lambda6 * L_set4;

components = struct("wetData", L_wet, "dryData", L_dry, ...
    "physics1", L_set1, "physics2", L_set2, "physics3", L_set3, "physics4", L_set4);
end

function result = train_parametric_swrc_model(dataBundle, cfg, options)
% TRAIN_PARAMETRIC_SWRC_MODEL Train the proposed or ablation parametric model.

arguments
    dataBundle struct
    cfg struct
    options.modelName string = "parametric_model"
    options.useDualBranch logical = false
    options.useHighOCEnhancement logical = true
    options.usePhysics logical = true
    options.useSplitDataLoss logical = cfg.training.parametric.useSplitDataLoss
    options.stage1Epochs double = cfg.training.parametric.stage1Epochs
    options.stage2Epochs double = cfg.training.parametric.stage2Epochs
    options.lrStage1 double = cfg.training.parametric.lrStage1
    options.lrStage2 double = cfg.training.parametric.lrStage2
    options.highOCWeight double = cfg.training.parametric.highOCWeight
    options.lambdaWet double = cfg.training.parametric.lambdaWet
    options.lambdaDry double = cfg.training.parametric.lambdaDry
    options.lambdaOC1 double = cfg.training.physics.lambdaOC1
    options.lambdaOC2 double = cfg.training.physics.lambdaOC2
    options.lambdaOC3 double = cfg.training.physics.lambdaOC3
    options.lambdaSat double = cfg.training.physics.lambdaSat
    options.lambdaReg double = cfg.training.physics.lambdaReg
    options.usePlateauAnchor logical = cfg.training.parametric.usePlateauAnchor
    options.lambdaPlateau double = cfg.training.parametric.lambdaPlateau
    options.freezeTrunk logical = false
    options.seedOverride double = cfg.seed
    options.initParams = []
    options.customTrainData = struct()
    options.customValData = struct()
end

if ~isempty(options.customTrainData) && isstruct(options.customTrainData) && isfield(options.customTrainData, "nCurves")
    trainData = options.customTrainData;
else
    trainData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "train", dataBundle.normStats, cfg);
end
if ~isempty(options.customValData) && isstruct(options.customValData) && isfield(options.customValData, "nCurves")
    valData = options.customValData;
else
    valData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "val", dataBundle.normStats, cfg);
end

if ~isempty(options.initParams)
    params = options.initParams;
else
    params = init_model_params("parametric", options.useDualBranch, options.seedOverride);
end
[avgGrad, avgSqGrad] = param_init_optimizer_state(params);
history = param_init_history();
iteration = 0;
progressState = init_training_progress_state(cfg, options.modelName + " loss", true);

bestParams = params;
bestValRmse = inf;

stageDefs = {
    struct("name", "stage1", "epochs", options.stage1Epochs, "lr", options.lrStage1), ...
    struct("name", "stage2", "epochs", options.stage2Epochs, "lr", options.lrStage2)
    };

for s = 1:numel(stageDefs)
    if s == 2 && options.stage2Epochs <= 0
        continue;
    end

    for epoch = 1:stageDefs{s}.epochs
        iteration = iteration + 1;
        [lossValue, grads, components] = dlfeval(@parametric_gradients, params, trainData, cfg, options, stageDefs{s}.name);
        grads = param_clip_gradients(grads, cfg.training.gradientClip);
        [params, avgGrad, avgSqGrad] = adam_update_struct( ...
            params, grads, avgGrad, avgSqGrad, iteration, stageDefs{s}.lr, ...
            cfg.training.beta1, cfg.training.beta2, cfg.training.adamEpsilon);

        history = param_append_history(history, s, epoch, lossValue, components);
        if mod(epoch, cfg.training.verboseEvery) == 0 || epoch == 1 || epoch == stageDefs{s}.epochs
            if valData.nCurves > 0 && height(valData.pointTable) > 0
                valEval = evaluate_single_model(struct("kind","parametric","params",params, ...
                    "useDualBranch",options.useDualBranch,"name",options.modelName), valData, cfg);
            else
                valEval = struct("metrics", struct("RMSE", history.total(end)));
            end
            progressState = update_training_progress_state(progressState, epoch + (s-1)*1000, ...
                history.total(end), valEval.metrics.RMSE, stageDefs{s}.name);
            fprintf("[%s|%s] Epoch %d/%d | Loss %.6f | Val RMSE %.6f\n", ...
                options.modelName, stageDefs{s}.name, epoch, stageDefs{s}.epochs, ...
                history.total(end), valEval.metrics.RMSE);
            if valEval.metrics.RMSE < bestValRmse
                bestValRmse = valEval.metrics.RMSE;
                bestParams = params;
            end
        end
    end
end

model = struct();
model.kind = "parametric";
model.name = options.modelName;
model.params = bestParams;
model.useDualBranch = options.useDualBranch;
model.options = options;
model.bestValRMSE = bestValRmse;

result = struct();
result.model = model;
result.history = history;
result.trainData = trainData;
result.valData = valData;

save(fullfile(cfg.outputsModelsDir, options.modelName + ".mat"), "model", "history", "options");
end

function [lossValue, grads, components] = parametric_gradients(params, trainData, cfg, options, stageName)
[lossValue, components] = loss_parametric_swrc(params, trainData, cfg, options, stageName);
grads = dlgradient(lossValue, params);
if isfield(options, "freezeTrunk") && options.freezeTrunk
    grads = param_zero_trunk_grads(grads, options.useDualBranch);
end
end

function [avgGrad, avgSqGrad] = param_init_optimizer_state(params)
avgGrad = param_map_struct(params, @(x) dlarray(zeros(size(extractdata(x)), "single")));
avgSqGrad = param_map_struct(params, @(x) dlarray(zeros(size(extractdata(x)), "single")));
end

function out = param_map_struct(in, fn)
out = struct();
fields = fieldnames(in);
for i = 1:numel(fields)
    item = in.(fields{i});
    if isstruct(item)
        out.(fields{i}) = param_map_struct(item, fn);
    else
        out.(fields{i}) = fn(item);
    end
end
end

function grads = param_zero_trunk_grads(grads, useDualBranch)
if useDualBranch
    if isfield(grads, "branchA")
        grads.branchA = param_map_struct(grads.branchA, @(x) dlarray(zeros(size(extractdata(x)), "single")));
    end
    if isfield(grads, "branchB")
        grads.branchB = param_map_struct(grads.branchB, @(x) dlarray(zeros(size(extractdata(x)), "single")));
    end
else
    if isfield(grads, "net")
        frozenFields = ["W1","b1","W2","b2","W3","b3","W4","b4"];
        for i = 1:numel(frozenFields)
            f = char(frozenFields(i));
            if isfield(grads.net, f)
                grads.net.(f) = dlarray(zeros(size(extractdata(grads.net.(f))), "single"));
            end
        end
    end
end
end

function grads = param_clip_gradients(grads, clipValue)
fields = fieldnames(grads);
for i = 1:numel(fields)
    item = grads.(fields{i});
    if isstruct(item)
        grads.(fields{i}) = param_clip_gradients(item, clipValue);
    else
        g = extractdata(item);
        grads.(fields{i}) = dlarray(single(max(-clipValue, min(clipValue, g))));
    end
end
end

function history = param_init_history()
history = struct("stage", [], "epoch", [], "total", [], "data", [], "oc", [], "sat", [], "plateau", [], "reg", []);
end

function history = param_append_history(history, stageIndex, epoch, lossValue, components)
history.stage(end + 1, 1) = stageIndex;
history.epoch(end + 1, 1) = epoch;
history.total(end + 1, 1) = param_scalarize(lossValue);
history.data(end + 1, 1) = param_scalarize(components.data);
history.oc(end + 1, 1) = param_scalarize(components.oc);
history.sat(end + 1, 1) = param_scalarize(components.sat);
history.plateau(end + 1, 1) = param_scalarize(components.plateau);
history.reg(end + 1, 1) = param_scalarize(components.reg);
end

function x = param_scalarize(v)
x = double(gather(extractdata(v)));
if isempty(x) || ~isfinite(x)
    x = 1e6;
end
end

function result = train_point_pinn_baseline(dataBundle, cfg, options)
% TRAIN_POINT_PINN_BASELINE Train the WRR-style pointwise PINN baseline.

arguments
    dataBundle struct
    cfg struct
    options.modelName string = "point_pinn_baseline"
    options.lossVariant string = cfg.training.point.lossVariant
    options.epochs double = cfg.training.point.epochs
    options.learningRate double = cfg.training.point.lr
    options.seedOverride double = cfg.seed
    options.initParams = []
    options.customTrainData = struct()
    options.customValData = struct()
end

if ~isempty(options.customTrainData) && isstruct(options.customTrainData) && isfield(options.customTrainData, "pointTable")
    trainData = options.customTrainData;
else
    trainData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "train", dataBundle.normStats, cfg);
end
if ~isempty(options.customValData) && isstruct(options.customValData) && isfield(options.customValData, "pointTable")
    valData = options.customValData;
else
    valData = build_curve_array_data(dataBundle.curveTable, dataBundle.pointTable, "val", dataBundle.normStats, cfg);
end
if strcmpi(options.lossVariant, "equation4_strict")
    trainData.wrrResidualSets = build_wrr_residual_sets(trainData, cfg);
else
    trainData.wrrResidualSets = struct("set1Norm", [], "set2Norm", [], "set3Norm", [], "set4Norm", []);
end

if ~isempty(options.initParams)
    params = options.initParams;
else
    params = init_model_params("point", false, options.seedOverride);
end
[avgGrad, avgSqGrad] = point_init_optimizer_state(params);
history = struct("epoch", [], "total", []);
bestParams = params;
bestValRmse = inf;
progressState = init_training_progress_state(cfg, options.modelName + " loss", false);

for epoch = 1:options.epochs
    [lossValue, grads] = dlfeval(@point_gradients, params, trainData, cfg, options);
    grads = point_clip_gradients(grads, cfg.training.gradientClip);
    [params, avgGrad, avgSqGrad] = adam_update_struct(params, grads, avgGrad, avgSqGrad, ...
        epoch, options.learningRate, cfg.training.beta1, cfg.training.beta2, cfg.training.adamEpsilon);

    history.epoch(end + 1, 1) = epoch;
    history.total(end + 1, 1) = point_scalarize(lossValue);

    if mod(epoch, cfg.training.verboseEvery) == 0 || epoch == 1 || epoch == options.epochs
        if isempty(valData.pointTable)
            valRmse = history.total(end);
        else
            valEval = evaluate_single_model(struct("kind","point","params",params,"name",options.modelName), valData, cfg);
            valRmse = valEval.metrics.RMSE;
        end
        progressState = update_training_progress_state(progressState, epoch, history.total(end), valRmse, "train");
        fprintf("[%s] Epoch %d/%d | Loss %.6f | Val RMSE %.6f\n", ...
            options.modelName, epoch, options.epochs, history.total(end), valRmse);
        if valRmse < bestValRmse
            bestValRmse = valRmse;
            bestParams = params;
        end
    end
end

model = struct("kind","point","params",bestParams,"name",options.modelName, ...
    "bestValRMSE",bestValRmse,"lossVariant",options.lossVariant);
result = struct("model", model, "history", history);
save(fullfile(cfg.outputsModelsDir, options.modelName + ".mat"), "model", "history", "options");
end

function state = init_training_progress_state(cfg, figureTitle, isParametric)
% Model-only public release: no training-progress figure is created.
state = struct();
state.enabled = false;
state.figure = [];
state.axis = [];
state.lossLine = [];
state.valLine = [];
state.x = [];
state.loss = [];
state.val = [];
state.title = figureTitle;
state.isParametric = isParametric;
end

function state = update_training_progress_state(state, xValue, lossValue, valValue, stageLabel)
% Model-only public release: keep scalar history only, no plotting.
if ~isfield(state, "x") || isempty(state.x)
    state.x = [];
    state.loss = [];
    state.val = [];
end
state.x(end+1) = xValue;
state.loss(end+1) = lossValue;
state.val(end+1) = valValue;
state.stageLabel = stageLabel;
end
function [lossValue, grads] = point_gradients(params, trainData, cfg, options)
[lossValue, ~] = loss_point_pinn(params, trainData, cfg, options);
grads = dlgradient(lossValue, params);
end

function [avgGrad, avgSqGrad] = point_init_optimizer_state(params)
avgGrad = point_map_struct(params, @(x) dlarray(zeros(size(extractdata(x)), "single")));
avgSqGrad = point_map_struct(params, @(x) dlarray(zeros(size(extractdata(x)), "single")));
end

function out = point_map_struct(in, fn)
out = struct();
fields = fieldnames(in);
for i = 1:numel(fields)
    item = in.(fields{i});
    if isstruct(item)
        out.(fields{i}) = point_map_struct(item, fn);
    else
        out.(fields{i}) = fn(item);
    end
end
end

function grads = point_clip_gradients(grads, clipValue)
fields = fieldnames(grads);
for i = 1:numel(fields)
    item = grads.(fields{i});
    if isstruct(item)
        grads.(fields{i}) = point_clip_gradients(item, clipValue);
    else
        g = extractdata(item);
        grads.(fields{i}) = dlarray(single(max(-clipValue, min(clipValue, g))));
    end
end
end

function x = point_scalarize(v)
x = double(gather(extractdata(v)));
if isempty(x) || ~isfinite(x)
    x = 1e6;
end
end

function result = train_retc_baseline(dataBundle, cfg)
% TRAIN_RETC_BASELINE Fit curve-wise VG parameters and regress them from soil features.

curveTable = fit_vg_curve_table(dataBundle.curveTable, dataBundle.pointTable, cfg);
trainMask = curveTable.split == "train" & curveTable.vg_fit_success;
valMask = curveTable.split == "val" & curveTable.vg_fit_success;

XTrain = normalize_minmax_apply(curveTable{trainMask, cfg.soilFeatureColumns}, dataBundle.normStats.curve);
XVal = normalize_minmax_apply(curveTable{valMask, cfg.soilFeatureColumns}, dataBundle.normStats.curve);

thetaUpperTrain = curveTable.theta_s_upper(trainMask);
thetaSratio = min(0.99, max(1e-4, curveTable.vg_theta_s(trainMask) ./ max(thetaUpperTrain, 1e-6)));
thetaRratio = min(0.99, max(1e-4, curveTable.vg_theta_r(trainMask) ./ max(curveTable.vg_theta_s(trainMask), 1e-6)));
YTrain = [ ...
    log(thetaRratio ./ (1 - thetaRratio)), ...
    log(thetaSratio ./ (1 - thetaSratio)), ...
    log(max(curveTable.vg_alpha(trainMask), 1e-6)), ...
    log(max(curveTable.vg_n(trainMask) - 1, 1e-6))];

W = ridge_regression(XTrain, YTrain, cfg.model.retcRidge);
valPred = apply_ridge_regression(XVal, W);
valRmse = sqrt(mean((valPred - YTrain(1:min(size(valPred,1), size(YTrain,1)), :)).^2, "all")); %#ok<NASGU>

model = struct();
model.kind = "retc";
model.name = "retc_vg_baseline";
model.W = W;
model.normStats = dataBundle.normStats.curve;
model.cfg = cfg;

result = struct();
result.model = model;
result.curveTableWithFits = curveTable;

save(fullfile(cfg.outputsModelsDir, "retc_vg_baseline.mat"), "model", "curveTable");
end

function W = ridge_regression(X, Y, lambda)
X1 = [ones(size(X, 1), 1), X];
I = eye(size(X1, 2));
I(1,1) = 0;
W = (X1' * X1 + lambda * I) \ (X1' * Y);
end

function Y = apply_ridge_regression(X, W)
Y = [ones(size(X, 1), 1), X] * W;
end

function pred = predict_model_on_split(model, splitData, cfg)
% PREDICT_MODEL_ON_SPLIT Generate pointwise predictions for one split.

switch string(model.kind)
    case "point"
        yPred = double(extractdata(forward_point_model(model.params, splitData.XPointNorm)))';
        thetaUpper = splitData.pointThetaUpper;
        layerIds = splitData.pointTable.layer_id;
        parameterValidityRate = NaN;

    case {"parametric","retc"}
        paramTable = predict_curve_parameters(model, splitData, cfg);
        yPred = zeros(height(splitData.pointTable), 1);
        thetaUpper = zeros(height(splitData.pointTable), 1);
        for i = 1:splitData.nCurves
            mask = splitData.curveIndexByPoint == i;
            pF = splitData.pointTable.pF(mask);
            pStruct = struct();
            pStruct.theta_r = dlarray(single(paramTable.theta_r(i)));
            pStruct.theta_s = dlarray(single(paramTable.theta_s(i)));
            pStruct.alpha = dlarray(single(paramTable.alpha(i)));
            pStruct.n = dlarray(single(paramTable.n(i)));
            pStruct.m = dlarray(single(1 - 1 / paramTable.n(i)));
            thetaCurve = double(extractdata(vg_curve_eval(pStruct, pF')));
            yPred(mask) = thetaCurve(:);
            thetaUpper(mask) = paramTable.theta_s_upper(i);
        end
        layerIds = splitData.pointTable.layer_id;
        validMask = paramTable.theta_r >= 0 & paramTable.theta_s > paramTable.theta_r & ...
            paramTable.theta_s <= paramTable.theta_s_upper + 1e-8 & ...
            paramTable.alpha > 0 & paramTable.n > 1;
        parameterValidityRate = mean(validMask);

    otherwise
        error("Unsupported model kind: %s", string(model.kind));
end

pred = struct();
pred.yTrue = splitData.pointTheta;
pred.yPred = yPred;
pred.thetaUpper = thetaUpper;
pred.layerIds = layerIds;
pred.parameterValidityRate = parameterValidityRate;
end

function paramTable = predict_curve_parameters(model, splitData, cfg)
switch string(model.kind)
    case "parametric"
        pred = forward_parametric_model(model.params, splitData.XCurveNorm, splitData.XCurveRaw, cfg, model.useDualBranch);
        paramTable = table( ...
            double(extractdata(pred.theta_r))', ...
            double(extractdata(pred.theta_s))', ...
            double(extractdata(pred.theta_s_upper))', ...
            double(extractdata(pred.alpha))', ...
            double(extractdata(pred.n))', ...
            'VariableNames', {'theta_r','theta_s','theta_s_upper','alpha','n'});

    case "retc"
        XNorm = normalize_minmax_apply(splitData.XCurveRaw, model.normStats);
        Z = [ones(size(XNorm,1),1), XNorm] * model.W;
        thetaS = splitData.thetaSUpper .* sigmoid(Z(:,2));
        thetaR = thetaS .* sigmoid(Z(:,1)) * 0.98;
        alpha = exp(Z(:,3)) + cfg.physics.alphaEpsilon;
        n = 1 + exp(Z(:,4)) + cfg.physics.nEpsilon;
        paramTable = table(thetaR, thetaS, splitData.thetaSUpper, alpha, n, ...
            'VariableNames', {'theta_r','theta_s','theta_s_upper','alpha','n'});

    otherwise
        error("Curve parameter prediction only applies to parametric/retc models.");
end
end

function metrics = compute_regression_metrics(yTrue, yPred)
% COMPUTE_REGRESSION_METRICS Standard pointwise accuracy metrics.

metrics = struct();
metrics.R2 = 1 - sum((yTrue - yPred).^2) / max(sum((yTrue - mean(yTrue)).^2), eps);
metrics.RMSE = sqrt(mean((yTrue - yPred).^2));
metrics.MAE = mean(abs(yTrue - yPred));
metrics.MAPE = mean(abs((yTrue - yPred) ./ max(abs(yTrue), 1e-6))) * 100;
metrics.MBE = mean(yPred - yTrue);
end

function evalResult = evaluate_single_model(model, splitData, cfg)
% EVALUATE_SINGLE_MODEL Evaluate one model on one split dataset.

pred = predict_model_on_split(model, splitData, cfg);
if isempty(pred.yTrue)
    evalResult = struct();
    evalResult.modelName = string(model.name);
    evalResult.splitName = splitData.name;
    emptyMetrics = compute_regression_metrics(nan, nan);
    emptyMetrics.CurveRMSEMean = NaN;
    emptyMetrics.CurveRMSEMedian = NaN;
    evalResult.metrics = emptyMetrics;
    evalResult.physics = struct("monotonicityRate", NaN, "thetaLtZeroRate", NaN, ...
        "invalidThetaRate", NaN, "thetaAboveUpperRate", NaN, "parameterValidityRate", NaN);
    evalResult.pred = pred;
    return;
end
yTrue = pred.yTrue(:);
yPred = pred.yPred(:);
layerIds = pred.layerIds(:);

metrics = compute_regression_metrics(yTrue, yPred);
curveRmse = curvewise_rmse(yTrue, yPred, layerIds);
metrics.CurveRMSEMean = mean(curveRmse);
metrics.CurveRMSEMedian = median(curveRmse);

physics = struct();
physics.monotonicityRate = check_model_monotonicity(model, splitData, cfg);
physics.thetaLtZeroRate = mean(yPred < 0);
physics.invalidThetaRate = mean(~isfinite(yPred) | yPred < 0 | yPred > pred.thetaUpper(:));
physics.thetaAboveUpperRate = mean(yPred > pred.thetaUpper(:));
physics.parameterValidityRate = pred.parameterValidityRate;

evalResult = struct();
evalResult.modelName = string(model.name);
evalResult.splitName = splitData.name;
evalResult.metrics = metrics;
evalResult.physics = physics;
evalResult.pred = pred;
end

function curveRmse = curvewise_rmse(yTrue, yPred, layerIds)
[g, ids] = findgroups(layerIds);
curveRmse = zeros(numel(ids), 1);
for i = 1:numel(ids)
    mask = g == i;
    curveRmse(i) = sqrt(mean((yTrue(mask) - yPred(mask)).^2));
end
end

function rate = check_model_monotonicity(model, splitData, cfg)
% CHECK_MODEL_MONOTONICITY Monotonicity rate on a dense pF grid by layer_id.

pFGrid = linspace(splitData.pFRange(1), splitData.pFRange(2), cfg.physics.monotonicityGridSize);
satisfied = false(splitData.nCurves, 1);
if splitData.nCurves == 0 || any(isnan(splitData.pFRange))
    rate = NaN;
    return;
end

switch string(model.kind)
    case "point"
        for i = 1:splitData.nCurves
            soil = splitData.XCurveRaw(i, :);
            pointRaw = [repmat(soil, numel(pFGrid), 1), pFGrid(:)];
            pointNorm = normalize_minmax_apply(pointRaw, splitData.normStats.point);
            y = double(extractdata(forward_point_model(model.params, pointNorm)))';
            satisfied(i) = all(diff(y) <= 1e-8);
        end

    case {"parametric","retc"}
        pred = predict_curve_parameters_local(model, splitData, cfg);
        for i = 1:splitData.nCurves
            pStruct.theta_r = dlarray(single(pred.theta_r(i)));
            pStruct.theta_s = dlarray(single(pred.theta_s(i)));
            pStruct.alpha = dlarray(single(pred.alpha(i)));
            pStruct.n = dlarray(single(pred.n(i)));
            pStruct.m = dlarray(single(1 - 1 / pred.n(i)));
            y = double(extractdata(vg_curve_eval(pStruct, pFGrid')));
            satisfied(i) = all(diff(y) <= 1e-8);
        end

    otherwise
        error("Unsupported model kind.");
end

rate = mean(satisfied);
end

function pred = predict_curve_parameters_local(model, splitData, cfg)
if string(model.kind) == "parametric"
    p = forward_parametric_model(model.params, splitData.XCurveNorm, splitData.XCurveRaw, cfg, model.useDualBranch);
    pred.theta_r = double(extractdata(p.theta_r))';
    pred.theta_s = double(extractdata(p.theta_s))';
    pred.alpha = double(extractdata(p.alpha))';
    pred.n = double(extractdata(p.n))';
else
    XNorm = normalize_minmax_apply(splitData.XCurveRaw, model.normStats);
    Z = [ones(size(XNorm,1),1), XNorm] * model.W;
    pred.theta_s = splitData.thetaSUpper .* (1 ./ (1 + exp(-Z(:,2))));
    pred.theta_r = pred.theta_s .* (1 ./ (1 + exp(-Z(:,1)))) * 0.98;
    pred.alpha = exp(Z(:,3)) + cfg.physics.alphaEpsilon;
    pred.n = 1 + exp(Z(:,4)) + cfg.physics.nEpsilon;
end
end

function files = save_figure_outputs(figHandle, baseFilePath, cfg)
% Model-only public release: figure export is intentionally disabled.
files = struct();
files.jpg = "";
end
function validation = validate_ternary_data(tbl)
% VALIDATE_TERNARY_DATA Check Sand+Silt+Clay consistency.

textureSum = tbl.Sand + tbl.Silt + tbl.Clay;
sumError = textureSum - 100;
tolerance = 2.0;

validation = struct();
validation.textureSum = textureSum;
validation.sumError = sumError;
validation.withinTolerance = abs(sumError) <= tolerance;
validation.passRate = mean(validation.withinTolerance);
validation.maxAbsError = max(abs(sumError));
validation.note = sprintf("Sand+Silt+Clay within +/- %.1f for %.2f%% of rows; max abs error = %.3f.", ...
    tolerance, 100 * validation.passRate, validation.maxAbsError);
end

function validation = validate_pf_theta_data(theta, pF, thetaRange, pFRange)
% VALIDATE_PF_THETA_DATA Validate theta and pF ranges.

thetaValid = isfinite(theta) & theta >= thetaRange(1) & theta <= thetaRange(2);
pFValid = isfinite(pF) & pF >= pFRange(1) & pF <= pFRange(2);

validation = struct();
validation.thetaValid = thetaValid;
validation.pFValid = pFValid;
validation.thetaPassRate = mean(thetaValid);
validation.pFPassRate = mean(pFValid);
validation.note = sprintf("Theta valid in %.2f%% of rows over [%g, %g]; pF valid in %.2f%% of rows over [%g, %g].", ...
    100 * validation.thetaPassRate, thetaRange(1), thetaRange(2), ...
    100 * validation.pFPassRate, pFRange(1), pFRange(2));
end

function validation = validate_metrics_table(tbl, expectedLabels)
% VALIDATE_METRICS_TABLE Ensure metrics map to expected model labels.

actualLabels = string(tbl.Model);
expectedLabels = string(expectedLabels(:));
missingLabels = setdiff(expectedLabels, actualLabels);
extraLabels = setdiff(actualLabels, expectedLabels);

validation = struct();
validation.pass = isempty(missingLabels) && isempty(extraLabels) && height(tbl) == numel(expectedLabels);
validation.missingLabels = missingLabels;
validation.extraLabels = extraLabels;
validation.note = compose_note(validation);
end

function note = compose_note(validation)
if validation.pass
    note = "Metric table labels match the intended model order.";
    return;
end

parts = strings(0, 1);
if ~isempty(validation.missingLabels)
    parts(end + 1, 1) = "Missing: " + strjoin(validation.missingLabels, ", "); %#ok<AGROW>
end
if ~isempty(validation.extraLabels)
    parts(end + 1, 1) = "Extra: " + strjoin(validation.extraLabels, ", "); %#ok<AGROW>
end
note = strjoin(parts, "; ");
end

function write_tables_to_excel(filePath, sheetNames, tables)
% WRITE_TABLES_TO_EXCEL Write several tables into one Excel workbook.

if isfile(filePath)
    delete(filePath);
end

usedNames = strings(0, 1);
for i = 1:numel(sheetNames)
    tbl = tables{i};
    if ~istable(tbl)
        error("Sheet %s must be provided as a table.", string(sheetNames{i}));
    end
    safeSheetName = sanitize_sheet_name(sheetNames{i}, usedNames);
    usedNames(end + 1, 1) = string(safeSheetName); %#ok<AGROW>
    writetable(tbl, filePath, "Sheet", safeSheetName);
end
end

function safeName = sanitize_sheet_name(sheetName, usedNames)
safeName = string(sheetName);
safeName = replace(safeName, [":","\", "/", "?", "*", "[", "]"], "_");
safeName = strtrim(safeName);
if strlength(safeName) == 0
    safeName = "Sheet";
end
if strlength(safeName) > 31
    safeName = extractBefore(safeName, 32);
end

baseName = safeName;
counter = 1;
while any(usedNames == safeName)
    suffix = "_" + string(counter);
    maxBaseLength = 31 - strlength(suffix);
    if strlength(baseName) > maxBaseLength
        safeName = extractBefore(baseName, maxBaseLength + 1) + suffix;
    else
        safeName = baseName + suffix;
    end
    counter = counter + 1;
end
end


