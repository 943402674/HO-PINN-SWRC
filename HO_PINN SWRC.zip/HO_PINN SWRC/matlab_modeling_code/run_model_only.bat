@echo off
setlocal
cd /d "%~dp0"
matlab -batch "main_model_only"
endlocal
