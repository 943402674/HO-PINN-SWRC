﻿# HO-PINN Model Code and Input Data

This folder contains the MATLAB modeling code and model input data needed to reproduce the model training and evaluation workflow for the manuscript.

## Contents

- `matlab_modeling_code/`
  - MATLAB model-only pipeline and launcher files.
  - Manuscript plotting, GIS rendering, figure-layout UI, and image-generation scripts are intentionally excluded.
- `data/raw_input/`
  - Source-domain SWRC input table used by the modeling pipeline.
- `data/processed_inputs/`
  - Cleaned point-level and curve-level modeling tables.
  - Curve and point split files used to reproduce the reported train/test partition.
- `MANIFEST_public_release.txt`
  - File inventory for this release folder.

## How to Run

1. Open MATLAB.
2. Set the working directory to `matlab_modeling_code`.
3. Run:

```matlab
main_model_only
```

or run `run_model_only.bat` from Windows if MATLAB is available on the system path configured in that file.

## Data and Code Scope

This release is designed for model reproducibility rather than figure reproduction. It includes the model input data and MATLAB modeling code only. The manuscript figure-generation scripts, plotting-data exporters, QGIS/ArcGIS map construction scripts, Visio diagram files, interactive layout tools, and final raster/vector figures are not included.

## Availability Statement Placeholder

The model input data and MATLAB code required to reproduce the reported modeling results will be made openly available in a GitHub repository upon publication:

`https://github.com/<owner>/<repository>`

The final repository URL and license should be inserted before submission or during proof correction.
